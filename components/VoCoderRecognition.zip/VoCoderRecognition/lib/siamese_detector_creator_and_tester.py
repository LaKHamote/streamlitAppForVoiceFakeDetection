import random
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models
from torch.utils.data import Dataset, DataLoader, random_split
from PIL import Image
import os
import torchvision.transforms as transforms
from datetime import datetime
from pathlib import Path
import torch.nn.init as init
import numpy as np


class SiameseVGG19(nn.Module):
    def __init__(self, normalize):
        super(SiameseVGG19, self).__init__()
        #Load pretrained VGG19
        vgg19 = models.vgg19(pretrained=False)
        #vgg19.requires_grad_(False)

        # Remove the last fully connected layer
        self.features = vgg19.features

        self.fc = nn.Sequential(
            nn.Linear(4096, 256),  # To reduce embedding
            nn.ReLU(),
            nn.Linear(256, 128),  # To reduce embedding
            nn.ReLU(),
            nn.Linear(128, 32),  # To reduce embedding
            nn.ReLU(),
            nn.Linear(32, 8),  # To reduce embedding
            nn.ReLU(),
            nn.Linear(8, 2)  # To reduce embedding
            #nn.Linear(8, 3)  # To reduce embedding

        )

        self._initialize_weights()

        self._normalize = normalize

    def _initialize_weights(self):
        # Initialize model weights
        # for m in self.modules():
        for m in self.fc.modules():
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.Linear):
                init.normal_(m.weight, mean=0.0, std=0.02)
                if m.bias is not None:
                    init.constant_(m.bias, 0)

    def forward(self, x):
        # Extract image features
        x = self.features(x)
        x = torch.flatten(x, 1)  # Flatten as features
        x = self.fc(x)  # Pass throw fully connected

        # Normalize the embedding
        if self._normalize:
           x = F.normalize(x, p=2, dim=1)
        return x


    def forward_once(self, x):
        return self.forward(x)


    def save_weights(self, file_path):
        torch.save(self.state_dict(), file_path)

    def load_weights(self, file_path):
        self.load_state_dict(torch.load(file_path))

class SiameseResNet34(nn.Module):
    def __init__(self, normalize):
        super(SiameseResNet34, self).__init__()
        # Load pretrained ResNet34
        resnet34 = models.resnet34(pretrained=False)
        #resnet34.requires_grad_(False)

        # Remove the last fully connected (fc) layer
        self.features = nn.Sequential(*list(resnet34.children())[:-1])  # All layers but the last (fc)

        # Camada fully connected customizada
        self.fc = nn.Sequential(
            nn.Linear(512, 256),  # To reduce embedding
            nn.ReLU(),
            nn.Linear(256, 128),  # To reduce embedding
            nn.ReLU(),
            nn.Linear(128, 32), # To reduce embedding
            nn.ReLU(),
            nn.Linear(32, 8),  # To reduce embedding
            nn.ReLU(),
            nn.Linear(8, 2)  # To reduce embedding
        )

        self._initialize_weights()

        self._normalize = normalize

    def _initialize_weights(self):
        #Initialize all model weights
        # for m in self.modules():
        for m in self.fc.modules():
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.Linear):
                init.normal_(m.weight, mean=0.0, std=0.02)
                if m.bias is not None:
                    init.constant_(m.bias, 0)

    def forward(self, x):
        # Extract image features
        x = self.features(x)  # Pass throw conv layers
        x = torch.flatten(x, 1)  # Flatten as features
        x = self.fc(x)  # Passa throw fully connected

        # Normaliz embedding (radius 1)
        if self._normalize:
           x = F.normalize(x, p=2, dim=1)

        return x


    def forward_once(self, x):
        return self.forward(x)

    def save_weights(self, file_path):
        torch.save(self.state_dict(), file_path)

    def load_weights(self, file_path):
        self.load_state_dict(torch.load(file_path))


class ImageInfo:
    def __init__(self, full_path, speaker, vocoder):
        self.full_path = full_path
        self.speaker = speaker
        self.vocoder = vocoder
        self.image = Image.open(full_path).convert('RGB')

# Custom DataLoader for Triplet Loading
class TripletDataset(Dataset):
    def getDirectory(self, speaker, vocoder):
        return self.dir_base + "/" + speaker + "/" + vocoder

    def getImagesInfo(self, speakers, vocoders):
        images_info = {}
        print("Loading images...")
        for speaker in speakers:
            for vocoder in vocoders:
                path = os.path.join(self.dir_base,speaker,vocoder)
                print(path)
                files = os.listdir(path)
                for file in files:
                    full_path = os.path.join(path,file)
                    image_info = ImageInfo(full_path, speaker, vocoder)
                    images_info[full_path]=image_info
        return images_info

    def getRandomPositiveNegativeImageInfo(self, image_info):

        random_vocoder =  random.choice(self.vocoders)
        while image_info.vocoder == random_vocoder:
            random_vocoder = random.choice(self.vocoders)

        random_speaker1 = random.choice(self.speakers)
        random_speaker2 = random.choice(self.speakers)
        if len(self.speakers) >= 2:
            while image_info.speaker == random_speaker1:
                random_speaker1 = random.choice(self.speakers)

        positive_directory = os.path.join(self.dir_base, random_speaker1, image_info.vocoder)

        if self.push_pull:
           negative_directory = os.path.join(self.dir_base, random_speaker1, random_vocoder)
        else:
           negative_directory = os.path.join(self.dir_base, random_speaker2, random_vocoder)


        positive_files = os.listdir(positive_directory)
        negative_files = os.listdir(negative_directory)

        positive_file = random.choice(positive_files)
        negative_file = random.choice(negative_files)

        positive_file = os.path.join(positive_directory, positive_file)
        negative_file = os.path.join(negative_directory, negative_file)

        positive_image_info = self.images_info[positive_file]
        negative_image_info = self.images_info[negative_file]


        return (positive_image_info, negative_image_info)

    def __init__(self, dir_base, speakers, vocoders, transform=None, push_pull=False):

        self.dir_base = dir_base
        self.speakers = speakers

        self.vocoders = vocoders

        self.images_info = self.getImagesInfo(speakers, vocoders)

        self.transform = transform

        self.push_pull = push_pull

    def __len__(self):
        return len(self.images_info)

    def __getitem__(self, idx):


        anchor_image_info = list(self.images_info.values())[idx]
        anchor_image = anchor_image_info.image

        positive_image_info, negative_image_info = self.getRandomPositiveNegativeImageInfo(anchor_image_info)

        positive_image = positive_image_info.image
        negative_image = negative_image_info.image

        anchor_image = self.transform(anchor_image)
        positive_image = self.transform(positive_image)
        negative_image = self.transform(negative_image)


        return anchor_image, positive_image, negative_image, anchor_image_info.vocoder, positive_image_info.vocoder, negative_image_info.vocoder


#Loss function for Triplet Loss
class TripletLossCustom(nn.Module):
    def __init__(self, normalize):
        super(TripletLossCustom, self).__init__()
        self._normalize = normalize

    def forward(self, anchor, positive, negative, anchor_vocoder, positive_vocoder, negative_vocoder):

        distance_positive = F.pairwise_distance(anchor, positive)
        distance_negative = F.pairwise_distance(anchor, negative)

        loss = distance_positive - distance_negative

        if not self._normalize:
           margin=1
           loss = torch.clamp(loss + margin, min=0.0)

        return loss.mean()


class InferenceHistory:
    def __init__(self, vocoders, speakers, filename, dataset_name):
        self.vocoders = vocoders
        self.speakers = speakers
        self.filename = filename
        self.dataset_name = dataset_name
        with open(self.filename, "w") as file:
            file.write("vocoder = [\n")
            for vocoder in vocoders:
                file.write(f"[\"{vocoder}\"]\n")
            file.write("];\n\n")

            file.write("speaker = [\n")
            for speaker in speakers:
                file.write(f"[\"{speaker}\"]\n")
            file.write("];\n\n")

            file.write(f"{self.dataset_name}_inference_history = [\n")


    def add_sample(self, epoch, speaker, vocoder, inference):
        with open(self.filename, "a") as file:
            file.write(f"[{epoch},{self.speakers.index(speaker)},{self.vocoders.index(vocoder)},")
            for j in range(inference.shape[1]):
                file.write(f"{inference[0, j].item()},")
            file.write("],\n")

    def finish(self):
        with open(self.filename, "a") as file:
            file.write("];\n")


class AccuracyMeter:
    def __init__(self, vocoders):
        self.vocoders = vocoders
        self.map = {value: i for i, value in enumerate(set(vocoders))}
        self.embedding_inferences = None
        self.ground_truth_vocoders = []
        self._result = {}

    def add_inference(self, batch_embedding_inferences, batch_ground_truth_vocoders):
        if self.embedding_inferences is None:
            self.embedding_inferences = batch_embedding_inferences
        else:
            self.embedding_inferences = torch.cat((self.embedding_inferences, batch_embedding_inferences), dim=0)

        list_values = [self.map[value] for value in batch_ground_truth_vocoders]
        self.ground_truth_vocoders.extend(list_values)

    def calc_inferred_vocoder(self, embedding_inference, mean_per_vocoder):
        n_vocoder = mean_per_vocoder[0][0]
        dist = F.pairwise_distance(mean_per_vocoder[0][1] , embedding_inference)

        i = 1
        while i<len(mean_per_vocoder):
            new_dist = F.pairwise_distance(mean_per_vocoder[i][1] , embedding_inference)
            if(new_dist<dist):
                dist = new_dist
                n_vocoder = mean_per_vocoder[i][0]
            i+=1

        return n_vocoder

    def calculate(self):
        #print("######### self.embedding_inferences ###########")
        #print(self.embedding_inferences)
        #print("######### self.ground_truth_vocoders ##########")
        #print(self.ground_truth_vocoders)

        device = self.embedding_inferences.device

        ground_truth_vocoders_tensor = torch.tensor(self.ground_truth_vocoders).unsqueeze(1)
        ground_truth_vocoders_tensor = ground_truth_vocoders_tensor.to(device)
        joined_tensors = torch.cat((ground_truth_vocoders_tensor, self.embedding_inferences), dim=1)

        #Separate column 0 (groups) and columns 1, 2, and 3 (values for the mean)
        groups = joined_tensors[:, 0]
        values = joined_tensors[:, 1:]

        #Identify the unique groups in column 0
        unique_groups = torch.unique(groups)

        #Calculate the mean for each group
        mean_per_vocoder = []
        for group in unique_groups:
            #Select the lines that belongs to the current group
            group_values = values[groups == group]

            #Calculate the mean in columns 1, 2, and 3 to the current group
            mean = group_values.mean(dim=0)

            #Store the mean along the group identificator
            mean_per_vocoder.append((group.item(), mean))

        #print("############ mean_per_vocoder ###############")
        #print(mean_per_vocoder)


        for n_vocoder in range(len(self.vocoders)):
            self._result[n_vocoder] = np.array([0,0,0,0])
        for i in range(len(self.embedding_inferences)):
            embedding_inference = self.embedding_inferences[i]
            inferred_vocoder = self.calc_inferred_vocoder(embedding_inference, mean_per_vocoder)
            ground_truth_vocoder = self.ground_truth_vocoders[i]
            #print(f"{i}   ground_truth_vocoder={ground_truth_vocoder} inferred_vocoder={inferred_vocoder}")

            for n_vocoder in range(len(self.vocoders)):
                #vocoder, tp, tn, fp, fn
                if inferred_vocoder==n_vocoder and ground_truth_vocoder==n_vocoder:
                    self._result[n_vocoder] = self._result[n_vocoder] + np.array([1,0,0,0])

                if (inferred_vocoder!=n_vocoder) and (ground_truth_vocoder!=n_vocoder):
                    self._result[n_vocoder] = self._result[n_vocoder] + np.array([0,1,0,0])

                if (inferred_vocoder==n_vocoder) and (ground_truth_vocoder!=n_vocoder):
                    self._result[n_vocoder] = self._result[n_vocoder] + np.array([0,0,1,0])

                if (inferred_vocoder!=n_vocoder) and (ground_truth_vocoder==n_vocoder):
                    self._result[n_vocoder] = self._result[n_vocoder] + np.array([0,0,0,1])

        return 0

    def get_f1_score(self, n_vocoder):
        result = self._result[n_vocoder]
        tp = result[0]
        fp = result[2]
        fn = result[3]

        precision = tp/(tp+fp)
        recall = tp/(tp+fn)

        return 2*(precision*recall)/(precision+recall)

    def get_er(self, n_vocoder):
        result = self._result[n_vocoder]
        tp = result[0]
        tn = result[1]
        fp = result[2]
        fn = result[3]

        return (fp+fn)/(tp+tn+fp+fn)

    def get_macro_f1_score(self):
        sum=0
        for n_vocoder in range(len(self.vocoders)):
            sum+=self.get_f1_score(n_vocoder)

        return sum/len(self.vocoders)

    def get_avg_er(self):
        sum = 0
        for n_vocoder in range(len(self.vocoders)):
            sum += self.get_er(n_vocoder)

        return sum / len(self.vocoders)


def create_and_test_siamese_detector(*,
                                     vocoders,
                                     speakers,
                                     external_speakers,
                                     num_epochs=10,
                                     dir_base,
                                     report_subdir=None,
                                     lr=1E-5,
                                     push_pull=False,
                                     cnn_base="vgg19",
                                     normalize=True,
                                     start_epoch=0,
                                     pre_trained_model=None):


    transform = transforms.Compose([
        transforms.RandomCrop((128, 64)),
        transforms.ToTensor()
        #transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])


    if report_subdir is None:
       just_now = datetime.now()
       report_subdir = "report_create_and_test_siamese_detector_" + just_now.strftime("%Y-%m-%d_%H-%M-%S")

    report_dir = os.path.join(dir_base, report_subdir)
    report_dir = Path(report_dir)

    report_dir.mkdir(parents=True)

    # PARAMETERS FILE
    content = "vocoders=" + str(vocoders) + "\n"
    content += "speakers=" + str(speakers) + "\n"
    content += "external_speakers=" + str(external_speakers) + "\n"
    content += "num_epochs=" + str(num_epochs) + "\n"
    content += "dir_base=" + dir_base + "\n"
    content += "report_subdir=" + str(report_subdir) + "\n"
    content += "lr=" + str(lr) + "\n"
    content += "push_pull=" + str(push_pull) + "\n"
    content += "cnn_base=" + cnn_base + "\n"
    content += "normalize=" + str(normalize) + "\n"
    content += "start_epoch=" + str(start_epoch) + "\n"
    content += "pre_trained_model=" + str(pre_trained_model) + "\n"
    filename = os.path.join(report_dir, "parameters.txt")
    with open(filename, "w") as file:
        file.write(content)


    #Create the dataset
    dataset = TripletDataset(dir_base, speakers, vocoders, transform=transform, push_pull=push_pull)

    external_datasets = []
    i = 0
    while i < len(external_speakers):
        external_speaker = [external_speakers[i]]
        external_dataset = TripletDataset(dir_base, external_speaker, vocoders, transform=transform)
        external_datasets.append(external_dataset)
        i += 1

    #Split the dataset in train (80%) e validation (20%)
    train_size = int(0.8 * len(dataset))
    val_size = len(dataset) - train_size
    train_dataset, val_dataset = random_split(dataset, [train_size, val_size])

    #Create dataloader for train and validation
    train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=64, shuffle=False)

    #Create external dataLoaders for generalization tests
    external_loaders = []
    for external_dataset in external_datasets:
        external_loader = DataLoader(external_dataset, batch_size=64, shuffle=False)
        external_loaders.append(external_loader)

    #Initializae model, optimizer and loss function
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if cnn_base == "vgg19":
        model = SiameseVGG19(normalize).to(device)
    elif cnn_base == "resnet34":
        model = SiameseResNet34(normalize).to(device)
    else:
        model = None

    if pre_trained_model != None:
        model.load_weights(pre_trained_model)

    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    criterion = TripletLossCustom(normalize)



    print(f"------------------------------------------------------------------------------")
    print(f" epoch        train_loss          val_loss        val_avg_er  val_macro_f1_scr")
    print(f"------------------------------------------------------------------------------")

    last_five_loss = [1.0, 2.0, 3.0, 4.0, 5.0]

    metric_filename = os.path.join(report_dir, "metric.txt")
    with open(metric_filename, "w") as file:
        file.write("epoch\ttrain_loss\tval_loss\tval_avg_er\tval_macro_f1_score")
        for i in range(len(external_loaders)):
            file.write(f"\texternal_avg_er_{i}\texternal_macro_f1_score_{i}")
        file.write("\n")

    train_inference_filename = os.path.join(report_dir, "train_inference.m")
    train_inference_history = InferenceHistory(vocoders, speakers, train_inference_filename, "train")

    valid_inference_filename = os.path.join(report_dir, "valid_inference.m")
    valid_inference_history = InferenceHistory(vocoders, speakers, valid_inference_filename, "valid")

    external_inference_filenames = []
    external_inference_histories = []
    for i in range(len(external_loaders)):
        external_speaker = [ external_speakers[i] ]
        external_inference_filename = os.path.join(report_dir, f"external_{i}_inference.m")
        external_inference_history = InferenceHistory(vocoders, external_speaker, external_inference_filename, f"external_{i}")
        external_inference_filenames.append(external_inference_filename)
        external_inference_histories.append(external_inference_history)

    min_val_loss = 1E100
    all_last_five_loss_same = False
    epoch=start_epoch
    while (epoch < num_epochs) and (not all_last_five_loss_same):
        #Train Loss
        model.train()
        train_loss = 0.0
        for anchor, positive, negative, anchor_vocoder, positive_vocoder, negative_vocoder in train_loader:
            optimizer.zero_grad()

            #Move the images to the device (GPU or CPU)
            anchor, positive, negative = anchor.to(device), positive.to(device), negative.to(device)

            # Forward pass for the three images
            anchor_out = model.forward_once(anchor)
            positive_out = model.forward_once(positive)
            negative_out = model.forward_once(negative)

            # Calc loss
            loss = criterion.forward(anchor_out, positive_out, negative_out, anchor_vocoder, positive_vocoder, negative_vocoder)
            loss.backward()
            optimizer.step()

            train_loss += loss.item()

        train_loss = train_loss / len(train_loader)

        #Valid Metrics
        with (torch.no_grad()):
            # Valid Loss and Accuracy
            val_accuracy = AccuracyMeter(vocoders)
            model.eval()
            val_loss = 0.0
            for anchor, positive, negative, anchor_vocoder, positive_vocoder, negative_vocoder in val_loader:
                anchor, positive, negative = anchor.to(device), positive.to(device), negative.to(device)

                anchor_out = model.forward_once(anchor)
                positive_out = model.forward_once(positive)
                negative_out = model.forward_once(negative)

                val_accuracy.add_inference(anchor_out, anchor_vocoder)
                loss = criterion.forward(anchor_out, positive_out, negative_out, anchor_vocoder, positive_vocoder, negative_vocoder)
                val_loss += loss.item()
            val_loss = val_loss / len(val_loader)

            val_accuracy.calculate()
            val_avg_er = val_accuracy.get_avg_er()
            val_macro_f1_score = val_accuracy.get_macro_f1_score()

            #External Accuracies
            external_avg_ers =[]
            external_macro_f1_scores = []
            if(min_val_loss > val_loss):
                min_val_loss = val_loss
                for external_loader in external_loaders:
                    external_accuracy = AccuracyMeter(vocoders)
                    model.eval()
                    for anchor, positive, negative, anchor_vocoder, positive_vocoder, negative_vocoder in external_loader:
                        anchor = anchor.to(device)

                        anchor_out = model.forward_once(anchor)

                        external_accuracy.add_inference(anchor_out, anchor_vocoder)

                    external_accuracy.calculate()
                    external_avg_er = external_accuracy.get_avg_er()
                    external_macro_f1_score = external_accuracy.get_macro_f1_score()
                    external_avg_ers.append(external_avg_er)
                    external_macro_f1_scores.append(external_macro_f1_score)
            else:
                for external_loader in external_loaders:
                    external_avg_ers.append(0)
                    external_macro_f1_scores.append(0)


            str_epoch = f"{epoch}"
            str_train_loss = f"{train_loss:.10f}"
            str_val_loss = f"{val_loss:.10f}"
            str_val_avg_er = f"{val_avg_er:.10f}"
            str_val_macro_f1_score = f"{val_macro_f1_score:.10f}"
            print(f" {str_epoch:>5} {str_train_loss:>17} {str_val_loss:>17} {str_val_avg_er:>17} {str_val_macro_f1_score:>17}")


            with open(metric_filename, "a") as file:
                file.write( f"{epoch}\t{train_loss}\t{val_loss}\t{val_avg_er}\t{val_macro_f1_score}")
                for i in range(len(external_loaders)):
                    file.write(f"\t{external_avg_ers[i]}\t{external_macro_f1_scores[i]}")
                file.write("\n")

            #Inference History
            train_dataset = train_loader.dataset.dataset
            n=300 #number of random points per epoch
            for i in range(n):
                image_info = random.choice(list(train_dataset.images_info.values()))
                image = image_info.image
                image = train_dataset.transform(image)
                image = image.to(device)
                image = image.unsqueeze(0)
                image_out = model.forward_once(image)
                train_inference_history.add_sample(epoch, image_info.speaker, image_info.vocoder, image_out)


            valid_dataset = val_loader.dataset.dataset
            n=300 #number of random points per epoch
            for i in range(n):
                image_info = random.choice(list(valid_dataset.images_info.values()))
                image = image_info.image
                image = valid_dataset.transform(image)
                image = image.to(device)
                image = image.unsqueeze(0)
                image_out = model.forward_once(image)
                valid_inference_history.add_sample(epoch, image_info.speaker, image_info.vocoder, image_out)

            for i in range(len(external_loaders)):
                external_loader = external_loaders[i]
                external_dataset = external_loader.dataset
                n=300 #number of random points per epoch
                for j in range(n):
                    image_info = random.choice(list(external_dataset.images_info.values()))
                    image = image_info.image
                    image = external_dataset.transform(image)
                    image = image.to(device)
                    image = image.unsqueeze(0)
                    image_out = model.forward_once(image)
                    external_inference_histories[i].add_sample(epoch, image_info.speaker, image_info.vocoder, image_out)

        last_five_loss.insert(0, val_loss)  # Insert loss
        last_five_loss.pop()
        all_last_five_loss_same = all(x == last_five_loss[0] for x in last_five_loss)

        #save model for this epoch
        model.save_weights(os.path.join(report_dir, "model.pth"))

        epoch+=1

    if(all_last_five_loss_same):
        print("Finished by vanishing gradient")

    train_inference_history.finish()
    valid_inference_history.finish()
    for external_inference_history in external_inference_histories:
        external_inference_history.finish()



def main():


    vocoders = ("ljspeech_full_band_melgan.v2", "ljspeech_hifigan.v1", "ljspeech_melgan.v3.long", "bonafide",
                "ljspeech_multi_band_melgan.v2", "ljspeech_parallel_wavegan.v3", "ljspeech_style_melgan.v1")
    # vocoders=("ljspeech_full_band_melgan.v2","ljspeech_hifigan.v1","ljspeech_melgan.v3.long",
    #         "ljspeech_multi_band_melgan.v2","ljspeech_parallel_wavegan.v3","ljspeech_style_melgan.v1")

    speakers = ("cmu_us_jmk_spec_mel_0", "cmu_us_rms_spec_mel_0")
    external_speakers = ["cmu_us_ksp_spec_mel_0", "cmu_us_ksp_spec_mel_0.001", "cmu_us_ksp_spec_mel_0.01",
                         "cmu_us_ksp_spec_mel_0.1", "cmu_us_ksp_spec_mel_1", "cmu_us_ksp_spec_mel_10",
                         "cmu_us_ksp_spec_mel_100"]


    create_and_test_siamese_detector(vocoders = vocoders,
                                     speakers=speakers,
                                     external_speakers=external_speakers,
                                     num_epochs=100,
                                     report_subdir = "/home/gustavorabelo/cross_speaker_test/")


if __name__ == "__main__":
    main()