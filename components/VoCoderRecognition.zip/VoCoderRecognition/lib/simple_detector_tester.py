import contextlib
from pathlib import Path
import os
import matplotlib.pyplot as plt
from fastai.vision.all import *
from datetime import datetime
from sklearn.metrics import roc_curve, RocCurveDisplay, auc
from scipy.interpolate import interp1d
from scipy.optimize import brentq



def test_simple_detector(*,
                        detector_model_file,
                        inference_mel_root_path,
                        cnn_arch,
                        report_dir,
                        title_basename,
                        crop_width=64,
                        bs = 32,
):
    report_dir=Path(report_dir)
    report_dir.mkdir(parents=True)

    # PARAMETERS FILE
    content = "detector_model_file=" + detector_model_file + "\n"
    content += "inference_mel_root_path=" + str(inference_mel_root_path) + "\n"
    content += "cnn_arch=" + str(cnn_arch) + "\n"
    content += "report_dir=" + str(report_dir) + "\n"
    content += "title_basename=" + str(title_basename) + "\n"
    content += "crop_width=" + str(crop_width) + "\n"
    content += "bs=" + str(bs) + "\n"


    filename = os.path.join(report_dir, "parameters.txt")
    with open(filename, "w") as file:
        file.write(content)


    dls = ImageDataLoaders.from_folder(
        inference_mel_root_path,
        valid_pct=0.3,
        item_tfms=RandomCrop( (128, crop_width) ),
        batch_tfms=[],
        bs=bs
    )

    learn = vision_learner(dls, cnn_arch, metrics=F1Score(average='macro'))
    learn.model_dir = ""
    learn.load(detector_model_file)


    # CONFUSION MATRIX
    interp = ClassificationInterpretation.from_learner(learn)
    interp.plot_confusion_matrix(figsize=(10, 10), normalize=True, norm_dec=4,
                             title="Confusion matrix\n" + title_basename)
    plt.savefig(Path(report_dir, f"confusion_matrix_{title_basename}.png".replace("\n","_")))
    plt.close()


    # ROC CURVE
    preds, targs = learn.get_preds()
    num_classes = len(learn.dls.vocab)
    class_names = learn.dls.vocab
    plt.figure(figsize=(10, 10))
    eer_avg = 0.0
    for i in range(num_classes):
        y_true = (targs == i).numpy()  #Create binary vector for class i
        y_score = preds[:, i].numpy()  #Probabilities for class i
        fpr, tpr, _ = roc_curve(y_true, y_score)
        roc_auc = auc(fpr, tpr)

        # Calcular o EER
        fnr = 1 - tpr  #False Negative Rate is complement of TPR
        eer_threshold = brentq(lambda x: 1. - x - interp1d(fpr, tpr)(x), 0., 1.)
        eer = interp1d(fpr, fnr)(eer_threshold)
        eer_avg += eer

        plt.plot(fpr, tpr, lw=2, label=f'{class_names[i]} (area = {roc_auc:.4f}, EER = {eer:.4f})')
    eer_avg = eer_avg / num_classes

    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title(f"Receiver Operating Characteristic - Multi-Class\n" + title_basename + "\naEER=" + str(eer_avg) )
    plt.legend(loc='lower right')
    plt.savefig(Path(report_dir, f"roc_{title_basename}.png".replace("\n","_")))
    plt.close()


    # SALICENCE MAP
    learn.model.eval()
    for i in range(num_classes):
        spec_subdir = Path(os.path.join(inference_mel_root_path, class_names[i]))
        img = ""
        for spec_img_file in spec_subdir.iterdir():
            img = PILImage.create(spec_img_file)
            break
        x, = learn.dls.test_dl([img]).one_batch()
        processed_img = learn.dls.decode((x,))[0][0]
        x.requires_grad_()

        output = learn.model(x)
        target_class = output.argmax(dim=1).item()
        output[0, target_class].backward()
        saliency, _ = torch.max(x.grad.data.abs(), dim=1)
        saliency_map = saliency[0].cpu().numpy()
        fig, axs = plt.subplots(1, 2, figsize=(12, 6))
        axs[0].imshow(processed_img.permute(1, 2, 0).cpu().numpy())
        axs[0].axis('off')
        axs[0].set_title("Processad Image - " + class_names[i])
        axs[1].imshow(saliency_map, cmap='magma')
        axs[1].axis('off')
        axs[1].set_title("Salience Map - " + class_names[i] + "\n" + title_basename)
        plt.savefig(Path(report_dir, class_names[i] + f"_salience_{title_basename}.png".replace("\n","_")))
        plt.close()





def main():
    test_simple_detector(
                    detector_model_file="./detector_model.pth",
                    detector_model_name="model_name",
                    cnn_arch=vgg19_bn,
                    inference_mel_root_paths=["./inference_mel_folder","./inference_mel_folder2",],
    )

if __name__ == "__main__":
    main()