import contextlib
from pathlib import Path
import os
import matplotlib.pyplot as plt
from fastai.vision.all import *
from sklearn.metrics import roc_curve, RocCurveDisplay, auc
from scipy.interpolate import interp1d
from scipy.optimize import brentq

def create_simple_detector(*,
                    spec_root_path,
                    report_dir,
                    cnn_arch_list=[resnet34],
                    epochs=10,
                    crop_width=64,
                    discard_if_too_narrow=True,
                    bs=32,
                    patience=20,
                    min_delta=0.001,
                    ):

    report_dir = Path(report_dir)
    report_dir.mkdir(parents=True)

    #PARAMETERS FILE
    content = "spec_root_path=" + spec_root_path + "\n"
    content += "cnn_arch_list=" + str(cnn_arch_list) + "\n"
    content += "epochs=" + str(epochs) + "\n"
    content += "crop_width=" + str(crop_width) + "\n"
    content += "discard_if_too_narrow=" + str(discard_if_too_narrow) + "\n"
    content += "bs=" + str(bs) + "\n"
    content += "patience=" + str(patience) + "\n"
    content += "min_delta=" + str(min_delta) + "\n"
    content += "report_dir=" + str(report_dir) + "\n"

    filename=os.path.join(report_dir, "parameters.txt")
    with open(filename, "w") as file:
        file.write(content)


    for cnn_arch in cnn_arch_list:
        cnn_arch_ = cnn_arch
        basic_filename = cnn_arch.__name__ + "_" + str(bs)
        spec_root_path = Path(spec_root_path)

        dls = ImageDataLoaders.from_folder(
            spec_root_path,
            valid_pct=0.3,
            item_tfms=RandomCrop( (128, crop_width) ),
            batch_tfms=[],
            bs=bs
        )

        early_stopping_cb = EarlyStoppingCallback(monitor='valid_loss', patience=patience, min_delta=min_delta)
        pth_file = Path(os.path.join(spec_root_path, basic_filename + ".pth"))
        if pth_file.exists():
            print("############ Loading " + cnn_arch.__name__ +  " ################")
            learn = vision_learner (dls, cnn_arch_, metrics=F1Score(average='macro'))
            learn.model_dir = ""
            print(str(pth_file))
            learn.load(basic_filename)
        else:
            learn = vision_learner(dls, cnn_arch_, metrics=F1Score(average='macro'))
            learn.model_dir = ""
            print("############ Training " + cnn_arch.__name__ +  " ################" )
            learn.fine_tune(epochs, cbs=[early_stopping_cb])
            print("salvando pth em " + str(pth_file))
            learn.save(basic_filename)

            #LOSS CURVE
            learn.recorder.plot_loss()
            plt.title("Loss curve of " + str(pth_file.name) )
            plt.savefig(Path(report_dir, basic_filename + "_loss.png"))
            plt.close()

        #SAMPLE_BATCH
        dls.show_batch()
        plt.suptitle("Sample of batch of " + str(pth_file.name) )
        plt.savefig(Path(report_dir, basic_filename + "_batch.png"))
        plt.close()

        #CONFUSION MATRIX
        interp = ClassificationInterpretation.from_learner(learn)
        interp.plot_confusion_matrix(figsize=(10, 10), normalize=True, norm_dec=4, title="Confusion matrix of " + str(pth_file.name) )
        plt.savefig(Path(report_dir, basic_filename + "_confusion_matrix.png"))
        plt.close()

        #CLASSIFICATION REPORT
        interp.print_classification_report()
        with open(Path(report_dir, basic_filename + "_classification_report.txt"), 'w') as f:
            with contextlib.redirect_stdout(f):
                interp.print_classification_report()

        #ROC CURVE
        preds, targs = learn.get_preds()
        num_classes = len(learn.dls.vocab)
        class_names = learn.dls.vocab
        plt.figure(figsize=(10, 10))
        eer_avg = 0.0
        for i in range(num_classes):
            y_true = (targs == i).numpy()  #Create binary vector for class i
            y_score = preds[:, i].numpy()  #Probabilities for class i
            fpr, tpr, _ = roc_curve(y_true, y_score)
            roc_auc = auc(fpr, tpr)

            #Calc EER
            fnr = 1 - tpr  # False Negative Rate é o complemento do TPR
            eer_threshold = brentq(lambda x: 1. - x - interp1d(fpr, tpr)(x), 0., 1.)
            eer = interp1d(fpr, fnr)(eer_threshold)
            eer_avg += eer

            plt.plot(fpr, tpr, lw=2, label=f'{class_names[i]} (area = {roc_auc:.4f}, EER = {eer:.4f})')
        eer_avg = eer_avg / num_classes

        plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title(f"Receiver Operating Characteristic - Multi-Class\n" + str(pth_file.name) + f"  EER = {eer_avg:.5f}" )
        plt.legend(loc='lower right')
        plt.savefig(Path(report_dir, basic_filename + "_roc.png"))
        plt.close()

        #SALICENCE MAP
        learn.model.eval()
        for i in range(num_classes):
            spec_subdir = Path(os.path.join(spec_root_path, class_names[i]))
            img = ""
            for spec_img_file in spec_subdir.iterdir():
                img = PILImage.create(spec_img_file)
                break
            x, = learn.dls.test_dl([img]).one_batch()
            processed_img = learn.dls.decode((x,))[0][0]
            x.requires_grad_()

            output = learn.model(x)
            target_class = output.argmax(dim=1).item()
            output[0, target_class].backward()
            saliency, _ = torch.max(x.grad.data.abs(), dim=1)
            saliency_map = saliency[0].cpu().numpy()
            fig, axs = plt.subplots(1, 2, figsize=(12, 6))
            axs[0].imshow(processed_img.permute(1, 2, 0).cpu().numpy())
            axs[0].axis('off')
            axs[0].set_title("Processed image - " + class_names[i])
            axs[1].imshow(saliency_map, cmap='magma')
            axs[1].axis('off')
            axs[1].set_title("Salience Map " + str(pth_file.name)  )
            plt.savefig(Path(report_dir, basic_filename + "_" + class_names[i] + "_salience.png"))
            plt.close()



def main():
    create_simple_detector(spec_root_path="/home/gustavo_vrr/mestrado/spec_fake_test",
                           report_dir = "/home/gustavo_vrr/mestrado/report_fake_test",
                           cnn_arch_list=[alexnet],
                           epochs=3)




if __name__ == "__main__":
    main()
