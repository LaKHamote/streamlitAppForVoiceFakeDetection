#Most of this code was copied with minor modifications from https://github.com/librosa.
#Copyright (c) 2013--2023, librosa development team.

import os
import librosa
import librosa.display
from librosa.core.spectrum import _spectrogram
import numpy as np
import matplotlib.pyplot as plt
from typing import Any, Optional
from pathlib import Path
import math

MAX_MEL = 128
MAX_FREQ = 20050

def hz_to_mel_custom(
    frequencies,
    transform, #'mel', 'linearmel', 'antimel'
    *,
    htk: bool = False,
) :
    if transform == 'antimel':
        frequencies = frequencies / MAX_FREQ * MAX_MEL
        mels =  mel_to_hz_custom(frequencies, htk=htk, transform='mel')
        mels = mels / MAX_FREQ * MAX_MEL
        return mels
    frequencies = np.asanyarray(frequencies)
    if transform == 'linearmel':
        return frequencies
    if transform != 'mel':
        raise Exception("Wrong value for transform!")

    if htk:
        mels: np.ndarray = 2595.0 * np.log10(1.0 + frequencies / 700.0)
        return mels
    # Fill in the linear part
    f_min = 0.0
    f_sp = 200.0 / 3
    mels = (frequencies - f_min) / f_sp
    # Fill in the log-scale part
    min_log_hz = 1000.0  # beginning of log region (Hz)
    min_log_mel = (min_log_hz - f_min) / f_sp  # same (Mels)
    logstep = np.log(6.4) / 27.0  # step size for log region
    if frequencies.ndim:
        # If we have array data, vectorize
        log_t = frequencies >= min_log_hz
        mels[log_t] = min_log_mel + np.log(frequencies[log_t] / min_log_hz) / logstep
    elif frequencies >= min_log_hz:
        # If we have scalar data, heck directly
        mels = min_log_mel + np.log(frequencies / min_log_hz) / logstep
    return mels

def mel_to_hz_custom(
    mels,
    transform, #'mel', 'linearmel', 'antimel'
    *,
    htk: bool = False
) :
    if transform == 'antimel':
        mels = mels / MAX_MEL * MAX_FREQ
        frequencies =  hz_to_mel_custom(mels, htk=htk, transform='mel')
        frequencies = frequencies / MAX_MEL * MAX_FREQ
        return frequencies
    mels = np.asanyarray(mels)
    if transform == 'linearmel':
        return mels
    if transform != 'mel':
        raise Exception("Wrong value for transform!")

    if htk:
        return 700.0 * (10.0 ** (mels / 2595.0) - 1.0)
    # Fill in the linear scale
    f_min = 0.0
    f_sp = 200.0 / 3
    freqs = f_min + f_sp * mels
    # And now the nonlinear scale
    min_log_hz = 1000.0  # beginning of log region (Hz)
    min_log_mel = (min_log_hz - f_min) / f_sp  # same (Mels)
    logstep = np.log(6.4) / 27.0  # step size for log region
    if mels.ndim:
        # If we have vector data, vectorize
        log_t = mels >= min_log_mel
        freqs[log_t] = min_log_hz * np.exp(logstep * (mels[log_t] - min_log_mel))
    elif mels >= min_log_mel:
        # If we have scalar data, check directly
        freqs = min_log_hz * np.exp(logstep * (mels - min_log_mel))
    return freqs


def mel_frequencies_custom(
    transform, #'mel', 'linearmel', 'antimel'
    n_mels: int = 128,
    *,
    fmin: float = 0.0,
    fmax: float = 11025.0,
    htk: bool = False
) -> np.ndarray:
    # 'Center freqs' of mel bands - uniformly spaced between limits
    min_mel = hz_to_mel_custom(fmin, transform, htk=htk)
    max_mel = hz_to_mel_custom(fmax, transform,  htk=htk)
    mels = np.linspace(min_mel, max_mel, n_mels)
    hz: np.ndarray = mel_to_hz_custom(mels, transform, htk=htk)
    return hz


def mel_custom(
    *,
    transform, #'mel', 'linearmel', 'antimel'
    sr: float,
    n_fft: int,
    n_mels: int = 128,
    fmin: float = 0.0,
    fmax: Optional[float] = None,
    htk: bool = False,
    norm = "slaney",
    dtype = np.float32,
) -> np.ndarray:
    if fmax is None:
        fmax = float(sr) / 2
    # Initialize the weights
    n_mels = int(n_mels)
    weights = np.zeros((n_mels, int(1 + n_fft // 2)), dtype=dtype)
    # Center freqs of each FFT bin
    fftfreqs = librosa.core.fft_frequencies(sr=sr, n_fft=n_fft)
    # 'Center freqs' of mel bands - uniformly spaced between limits
    mel_f = mel_frequencies_custom(transform, n_mels + 2, fmin=fmin, fmax=fmax, htk=htk)
    fdiff = np.diff(mel_f)
    ramps = np.subtract.outer(mel_f, fftfreqs)
    for i in range(n_mels):
        # lower and upper slopes for all bins
        lower = -ramps[i] / fdiff[i]
        upper = ramps[i + 2] / fdiff[i + 1]
        # .. then intersect them with each other and zero
        weights[i] = np.maximum(0, np.minimum(lower, upper))
    if isinstance(norm, str):
        if norm == "slaney":
            # Slaney-style mel is scaled to be approx constant energy per channel
            enorm = 2.0 / (mel_f[2 : n_mels + 2] - mel_f[:n_mels])
            weights *= enorm[:, np.newaxis]
        else:
            raise ParameterError(f"Unsupported norm={norm}")
    else:
        weights = util.normalize(weights, norm=norm, axis=-1)
    # Only check weights if f_mel[0] is positive
    if not np.all((mel_f[:-2] == 0) | (weights.max(axis=1) > 0)):
        # This means we have an empty channel somewhere
        warnings.warn(
            "Empty filters detected in mel frequency basis. "
            "Some channels will produce empty responses. "
            "Try increasing your sampling rate (and fmax) or "
            "reducing n_mels.",
            stacklevel=2,
        )
    return weights




def melspectrogram_custom(
    *,
    transform, #'mel', 'linearmel', 'antimel'
    y: Optional[np.ndarray] = None,
    sr: float = 22050,
    S: Optional[np.ndarray] = None,
    n_fft: int = 2048,
    hop_length: int = 512,
    win_length: Optional[int] = None,
    window = "hann",
    center: bool = True,
    pad_mode = "constant",
    power: float = 2.0,
    **kwargs: Any,
) -> np.ndarray:
    S, n_fft = _spectrogram(
        y=y,
        S=S,
        n_fft=n_fft,
        hop_length=hop_length,
        power=power,
        win_length=win_length,
        window=window,
        center=center,
        pad_mode=pad_mode,
    )
    # Build a Mel filter
    mel_basis = mel_custom(transform=transform, sr=sr, n_fft=n_fft, **kwargs)
    melspec: np.ndarray = np.einsum("...ft,mf->...mt", S, mel_basis, optimize=True)
    return melspec


def audio_to_spectrogram(transform, #'mel', 'linearmel', 'antimel',
                         audio_path,
                         sr,
                         noise):
    y, sr = librosa.load(audio_path, sr=sr)

    signal_power = np.mean(y ** 2)
    noise_power = signal_power * noise
    noise = np.sqrt(noise_power) * np.random.randn(len(y))
    y = y + noise

    hop_length = 512
    n_fft = 2048


    S = melspectrogram_custom(transform=transform, y=y, sr=sr, n_fft=n_fft,
                                           hop_length=hop_length)  # será que precisa de sr
    S_dB = librosa.power_to_db(S, ref=np.max)
    return S_dB, sr


def save_spectrogram(S_dB, sr, output_path, crop_width, discard_if_too_narrow):
    num_frames = S_dB.shape[1]
    size_spec = S_dB.shape[0]

    if discard_if_too_narrow and (num_frames < crop_width):
        pass
    else:
        dpi = 100
        width_in_inches = num_frames / dpi
        height_in_inches = size_spec / dpi

        fig = plt.figure(figsize=(width_in_inches, height_in_inches), dpi=dpi)
        ax = fig.add_axes([0, 0, 1, 1], frameon=False)
        ax.set_axis_off()

        librosa.display.specshow(S_dB, sr=sr, ax=ax)
        fig.savefig(output_path, dpi=dpi, bbox_inches='tight', pad_inches=0)
        plt.close(fig)

def calc_snr_db(noise_level):
    if noise_level == 0:
        return "+INF"
    else:
        return str(-10*math.log10(noise_level))


def generate_specs(transform, #'mel', 'linearmel', 'antimel',
                   spec_root_path,
                   audio_root_path,
                   noise,
                   crop_width=64,
                   discard_if_too_narrow=True):
    print(f"Created folder: {spec_root_path}")
    for audio_subdir in audio_root_path.iterdir():
        spec_subdir = os.path.join(spec_root_path, audio_subdir.name)
        spec_subdir = Path(spec_subdir)
        spec_subdir.mkdir(parents=True)

        for filename in os.listdir(audio_subdir):
            if filename.endswith('.wav'):
                generate_single_spec(transform,
                                    spec_subdir,
                                    audio_subdir,
                                    filename,
                                    noise,
                                    crop_width,
                                    discard_if_too_narrow
                                ) 

def generate_single_spec(transform,
                        spec_subdir,
                        audio_subdir,
                        audio_name,
                        noise,
                        crop_width,
                        discard_if_too_narrow
                    ):
        audio_path = os.path.join(audio_subdir, audio_name)
        output_path = os.path.join(spec_subdir, os.path.splitext(audio_name)[0] + '.png')
        sr = 22050
        S_dB, sr = audio_to_spectrogram(transform, audio_path, sr, noise)
        save_spectrogram(S_dB, sr, output_path, crop_width, discard_if_too_narrow)
        print(f"Processed {audio_name} and saved to {output_path}")






