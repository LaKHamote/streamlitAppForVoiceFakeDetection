import random
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models
from torch.utils.data import Dataset, DataLoader, random_split
from PIL import Image
import os
import torchvision.transforms as transforms
from datetime import datetime
from pathlib import Path
import torch.nn.init as init
import numpy as np


class SiameseVGG19(nn.Module):
    def __init__(self, normalize):
        super(SiameseVGG19, self).__init__()
        #Load pretrained VGG19
        vgg19 = models.vgg19(pretrained=False)
        #vgg19.requires_grad_(False)

        # Remove the last fully connected layer
        self.features = vgg19.features

        self.fc = nn.Sequential(
            nn.Linear(4096, 256),  # To reduce embedding
            nn.ReLU(),
            nn.Linear(256, 128),  # To reduce embedding
            nn.ReLU(),
            nn.Linear(128, 32),  # To reduce embedding
            nn.ReLU(),
            nn.Linear(32, 8),  # To reduce embedding
            #nn.ReLU(),
            #nn.Linear(8, 2)  # To reduce embedding

        )

        self._initialize_weights()

        self._normalize = normalize

    def _initialize_weights(self):
        # Initialize model weights
        # for m in self.modules():
        for m in self.fc.modules():
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.Linear):
                init.normal_(m.weight, mean=0.0, std=0.02)
                if m.bias is not None:
                    init.constant_(m.bias, 0)

    def forward(self, x):
        # Extract image features
        x = self.features(x)
        x = torch.flatten(x, 1)  # Flatten as features
        x = self.fc(x)  # Pass throw fully connected

        # Normalize the embedding
        if self._normalize:
           x = F.normalize(x, p=2, dim=1)
        return x


    def forward_once(self, x):
        return self.forward(x)


    def save_weights(self, file_path):
        torch.save(self.state_dict(), file_path)

    def load_weights(self, file_path):
        self.load_state_dict(torch.load(file_path))



class ImageInfo:
    def __init__(self, full_path, speaker, vocoder):
        self.full_path = full_path
        self.speaker = speaker
        self.vocoder = vocoder
        self.image = Image.open(full_path).convert('RGB')

# Custom DataLoader
class MelDataset(Dataset):

    def __init__(self, dir_base, speakers, vocoders, transform=None):

        self._dir_base = dir_base
        self._images_info = self.getImagesInfo(speakers, vocoders)
        self._transform = transform


    def getDirectory(self, speaker, vocoder):
        return self._dir_base + "/" + speaker + "/" + vocoder

    def getImagesInfo(self, speakers, vocoders):
        images_info = {}
        print("Loading images...")
        for speaker in speakers:
            for vocoder in vocoders:
                path = os.path.join(self._dir_base, speaker, vocoder)
                print(path)
                files = os.listdir(path)
                for file in files:
                    full_path = os.path.join(path,file)
                    image_info = ImageInfo(full_path, speaker, vocoder)
                    images_info[full_path]=image_info
        return images_info


    def __len__(self):
        return len(self._images_info)

    def __getitem__(self, idx):

        image_info = list(self._images_info.values())[idx]
        image = image_info.image
        transformed_image = self._transform(image)

        return transformed_image, image_info.vocoder




#Loss function
class BonafideLossCustom(nn.Module):
    def __init__(self, normalize):
        super(BonafideLossCustom, self).__init__()
        self._normalize = normalize

    def forward(self, x):

        print("-------------------");
        print("-------------------");
        print("\nEntrou no forward de Bonafide com shape = " + str(x.shape))
        print("x = \n" + str(x))

        loss = x*x;

        print("\nO loss ficou com shape = " + str(loss.shape))
        print("\nloss = \n" + str(loss))

        print("\nMas a média ficou: \n" + str(loss.mean()))

        print("-------------------");
        print("-------------------");
        print("-------------------");


        return loss.mean()

class SingleVocoderLossCustom(nn.Module):
    def __init__(self, normalize):
        super(SingleVocoderLossCustom, self).__init__()
        self._normalize = normalize

    def forward(self, x):


        loss = x*x;

        return loss.mean()

class MixedVocoderLossCustom(nn.Module):
    def __init__(self, normalize):
        super(MixedVocoderLossCustom, self).__init__()
        self._normalize = normalize

    def forward(self, x):


        loss = x*x;

        return loss.mean()



def create_and_test_siamese2_detector(*,
                                     vocoders,
                                     speakers,
                                     #external_speakers,
                                     #external_vocoders,
                                     num_epochs=10,
                                     dir_base,
                                     report_subdir=None,
                                     lr=1E-5,
                                     cnn_base="vgg19",
                                     normalize=False,
                                     start_epoch=0,
                                     pre_trained_model=None):

    if vocoders[0] != "bonafide":
        raise ValueError(f"Erro: vocoders[0] esperado é 'bonafide', mas foi encontrado '{vocoders[0]}'.")



    transform = transforms.Compose([
        transforms.RandomCrop((128, 64)),
        transforms.ToTensor()
    ])


    if report_subdir is None:
       just_now = datetime.now()
       report_subdir = "report_create_and_test_siamese_detector_" + just_now.strftime("%Y-%m-%d_%H-%M-%S")

    report_dir = os.path.join(dir_base, report_subdir)
    report_dir = Path(report_dir)

    report_dir.mkdir(parents=True)

    # PARAMETERS FILE
    content = "vocoders=" + str(vocoders) + "\n"
    content += "speakers=" + str(speakers) + "\n"
    #content += "external_speakers=" + str(external_speakers) + "\n"
    #content += "external_vocoders=" + str(external_vocoders) + "\n"
    content += "num_epochs=" + str(num_epochs) + "\n"
    content += "dir_base=" + dir_base + "\n"
    content += "report_subdir=" + str(report_subdir) + "\n"
    content += "lr=" + str(lr) + "\n"
    content += "cnn_base=" + cnn_base + "\n"
    content += "normalize=" + str(normalize) + "\n"
    content += "start_epoch=" + str(start_epoch) + "\n"
    content += "pre_trained_model=" + str(pre_trained_model) + "\n"
    filename = os.path.join(report_dir, "parameters.txt")
    with open(filename, "w") as file:
        file.write(content)


    #Create the dataset for bonafide (train and validation)
    bonafide_dataset = MelDataset(dir_base, speakers, ("bonafide",), transform=transform)
    train_bonafide_size = int(0.8 * len(bonafide_dataset))
    val_bonafide_size = len(bonafide_dataset) - train_bonafide_size
    train_bonafide_dataset, val_bonafide_dataset = random_split(bonafide_dataset, [train_bonafide_size, val_bonafide_size])

    #Create the dataset for all vocoders (train and validation)
    vocoder_dataset = MelDataset(dir_base, speakers, vocoders[1:], transform=transform)
    train_vocoder_size = int(0.8 * len(vocoder_dataset))
    val_vocoder_size = len(vocoder_dataset) - train_vocoder_size
    train_vocoder_dataset, val_vocoder_dataset = random_split(vocoder_dataset, [train_vocoder_size, val_vocoder_size])



    #Create dataloader for train and validation
    batch_size = len(vocoders[1:])
    train_bonafide_loader = DataLoader(train_bonafide_dataset, batch_size=batch_size, shuffle=True)
    val_bonafide_loader = DataLoader(val_bonafide_dataset, batch_size=batch_size, shuffle=False)


    #Initializae model, optimizer and loss function
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if cnn_base == "vgg19":
        model = SiameseVGG19(normalize).to(device)
    else:
        model = None

    if pre_trained_model is not None:
        model.load_weights(pre_trained_model)

    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    criterion_bonafide = BonafideLossCustom(normalize)
    criterion_single_vocoder = SingleVocoderLossCustom(normalize)
    criterion_mixed_vocoder = MixedVocoderLossCustom(normalize)



    print(f"--------------------------------------------------")
    print(f" epoch        train_loss          val_loss        ")
    print(f"--------------------------------------------------")

    last_five_loss = [1.0, 2.0, 3.0, 4.0, 5.0]

    metric_filename = os.path.join(report_dir, "metric.txt")
    with open(metric_filename, "w") as file:
        file.write("epoch\ttrain_loss\tval_loss")
        file.write("\n")


    all_last_five_loss_same = False
    epoch=start_epoch
    while (epoch < num_epochs) and (not all_last_five_loss_same):
        #Train Loss
        model.train()
        train_loss = 0.0
        for bonafide_image, bonafide_vocoder in train_bonafide_loader:

            #Create batch for one vocoder ramdomly choosen
            choosen_vocoder=random.choice(vocoders[1:])

            single_vocoder_image = []
            while len(single_vocoder_image) < batch_size:
                index = random.randrange(0, len(train_vocoder_dataset))
                transformed_image , vocoder = train_vocoder_dataset[index]
                if vocoder == choosen_vocoder:
                    single_vocoder_image.append(transformed_image)
            single_vocoder_image=torch.stack(single_vocoder_image)

            # Create batch for distinct vocoder ramdomly choosen
            mixed_vocoder_image = []
            mixed_vocoder_vocoder = []
            while len(mixed_vocoder_image) < batch_size:
                index = random.randrange(0, len(train_vocoder_dataset))
                transformed_image , vocoder = train_vocoder_dataset[index]
                already_in = False
                for i in range(len(mixed_vocoder_image)):
                    if mixed_vocoder_vocoder[i] == vocoder:
                        already_in = True
                if not already_in:
                    mixed_vocoder_image.append(transformed_image)
                    mixed_vocoder_vocoder.append(vocoder)
            mixed_vocoder_image=torch.stack(mixed_vocoder_image)

            optimizer.zero_grad()

            #Move the images to the device (GPU or CPU)
            bonafide_image = bonafide_image.to(device)
            single_vocoder_image = single_vocoder_image.to(device)
            mixed_vocoder_image = mixed_vocoder_image.to(device)

            # Forward pass
            bonafide_out = model.forward_once(bonafide_image)
            single_vocoder_out = model.forward_once(single_vocoder_image)
            mixed_vocoder_out = model.forward_once(mixed_vocoder_image)

            # Calc loss
            loss_bonafide = criterion_bonafide.forward(bonafide_out)
            loss_single_vocoder = criterion_single_vocoder.forward(single_vocoder_out)
            loss_mixed_vocoder = criterion_mixed_vocoder.forward(mixed_vocoder_out)

            loss = loss_bonafide + loss_single_vocoder + loss_mixed_vocoder
            loss.backward()
            optimizer.step()

            train_loss += loss.item()

        train_loss = train_loss / len(train_bonafide_loader)

        #Valid Metrics
        with (torch.no_grad()):
            # Valid Loss
            model.eval()
            val_loss = 0.0
            for bonafide_image , bonafide_vocoder  in val_bonafide_loader:

                # Create batch for one vocoder ramdomly choosen
                choosen_vocoder = random.choice(vocoders[1:])

                single_vocoder_image = []
                while len(single_vocoder_image) < batch_size:
                    index = random.randrange(0, len(val_vocoder_dataset))
                    transformed_image, vocoder = val_vocoder_dataset[index]
                    if vocoder == choosen_vocoder:
                        single_vocoder_image.append(transformed_image)
                single_vocoder_image=torch.stack(single_vocoder_image)

                # Create batch for distinct vocoder ramdomly choosen
                mixed_vocoder_image = []
                mixed_vocoder_vocoder = []
                while len(mixed_vocoder_image) < batch_size:
                    index = random.randrange(0, len(val_vocoder_dataset))
                    transformed_image, vocoder = val_vocoder_dataset[index]
                    already_in = False
                    for i in range(len(mixed_vocoder_image)):
                        if mixed_vocoder_vocoder[i] == vocoder:
                            already_in = True
                    if not already_in:
                        mixed_vocoder_image.append(transformed_image)
                        mixed_vocoder_vocoder.append(vocoder)
                mixed_vocoder_image=torch.stack(mixed_vocoder_image)

                bonafide_image = bonafide_image.to(device)
                single_vocoder_image = single_vocoder_image.to(device)
                mixed_vocoder_image = mixed_vocoder_image.to(device)

                bonafide_out = model.forward_once(bonafide_image)
                single_vocoder_out = model.forward_once(single_vocoder_image)
                mixed_vocoder_out = model.forward_once(mixed_vocoder_image)

                loss_bonafide = criterion_bonafide.forward(bonafide_out)
                loss_single_vocoder = criterion_single_vocoder.forward(single_vocoder_out)
                loss_mixed_vocoder = criterion_mixed_vocoder.forward(mixed_vocoder_out)

                loss = loss_bonafide + loss_single_vocoder + loss_mixed_vocoder

                val_loss += loss.item()
            val_loss = val_loss / len(val_bonafide_loader)



            str_epoch = f"{epoch}"
            str_train_loss = f"{train_loss:.10f}"
            str_val_loss = f"{val_loss:.10f}"
            print(f" {str_epoch:>5} {str_train_loss:>17} {str_val_loss:>17} ")


            with open(metric_filename, "a") as file:
                file.write( f"{epoch}\t{train_loss}")
                file.write("\n")




        last_five_loss.insert(0, val_loss)  # Insert loss
        last_five_loss.pop()
        all_last_five_loss_same = all(x == last_five_loss[0] for x in last_five_loss)

        #save model for this epoch
        model.save_weights(os.path.join(report_dir, "model.pth"))

        epoch+=1

    if(all_last_five_loss_same):
        print("Finished by vanishing gradient")




def main():


    vocoders = ("bonafide", "ljspeech_full_band_melgan.v2", "ljspeech_hifigan.v1", "ljspeech_melgan.v3.long",
                "ljspeech_multi_band_melgan.v2", "ljspeech_parallel_wavegan.v3", "ljspeech_style_melgan.v1")
    # vocoders=("ljspeech_full_band_melgan.v2","ljspeech_hifigan.v1","ljspeech_melgan.v3.long",
    #         "ljspeech_multi_band_melgan.v2","ljspeech_parallel_wavegan.v3","ljspeech_style_melgan.v1")

    speakers = ("cmu_us_jmk_spec_mel_0", "cmu_us_rms_spec_mel_0")
    external_speakers = ["cmu_us_ksp_spec_mel_0", "cmu_us_ksp_spec_mel_0.001", "cmu_us_ksp_spec_mel_0.01",
                         "cmu_us_ksp_spec_mel_0.1", "cmu_us_ksp_spec_mel_1", "cmu_us_ksp_spec_mel_10",
                         "cmu_us_ksp_spec_mel_100"]


    create_and_test_siamese2_detector(vocoders = vocoders,
                                     speakers=speakers,
                                     external_speakers=external_speakers,
                                     num_epochs=100,
                                     report_subdir = "/home/gustavorabelo/cross_speaker_test/")


if __name__ == "__main__":
    main()