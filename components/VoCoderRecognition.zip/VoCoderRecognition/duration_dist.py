import os
import librosa
import matplotlib.pyplot as plt
import argparse


def plot_audio_duration_distribution(audio_folder, output_file, title):
    """
    Function to calculate the duration of audio files in a folder and
    save a histogram of the duration distribution as an image.

    Parameters:
    - audio_folder (str): Path to the folder containing audio files.
    - output_file (str): Path to save the output image file (e.g., 'output.png').
    - title (str): Graph title.
    """
    # List to store the durations
    durations = []

    # Iterate over files in the folder
    for file in os.listdir(audio_folder):
        if file.endswith(".wav"):  # or .mp3 depending on your format
            file_path = os.path.join(audio_folder, file)
            # Load the audio file
            y, sr = librosa.load(file_path, sr=None)
            # Calculate the duration of the audio
            duration = librosa.get_duration(y=y, sr=sr)
            durations.append(duration)

    # Plot the duration distribution
    plt.hist(durations, bins=20, edgecolor='black')
    plt.xlim(0, 8)
    plt.title(title)
    plt.xlabel("Duration (seconds)")
    plt.ylabel("Qty")

    # Save the plot to the specified output file
    plt.savefig(output_file)
    plt.close()


if __name__ == "__main__":
    # Set up argument parsing
    parser = argparse.ArgumentParser(description="Generate and save a histogram of audio file durations.")
    parser.add_argument("audio_folder", help="Path to the folder containing audio files.")
    parser.add_argument("output_file", help="Path to save the output image file (e.g., 'output.png').")
    parser.add_argument("title", help="The graph title")

    # Parse the arguments
    args = parser.parse_args()

    # Call the function with the provided arguments
    plot_audio_duration_distribution(args.audio_folder, args.output_file, args.title)
