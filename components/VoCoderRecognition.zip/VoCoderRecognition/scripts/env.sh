export ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)" # /* para sair da pasta scripts
export DATASET_ORIGINAL=$ROOT_DIR/"dataset/original"
# export FILES_TO_KEEP=3 # Número de arquivos a manter por falante
export DATASET_GENERATED=$ROOT_DIR/"dataset/generated"
export REPORT="report"

export SPEAKERS=("awb" "bdl" "clb" "jmk" "ksp" "rms" "slt" ) # veja outros em http://festvox.org/cmu_arctic/
export STR_SPEAKERS=${SPEAKERS[@]}


export VOCODER_TAGS=("ljspeech_full_band_melgan.v2" \
                     "ljspeech_hifigan.v1" \
                     "ljspeech_melgan.v3.long" \
                     "ljspeech_multi_band_melgan.v2" \
                     "ljspeech_parallel_wavegan.v3" \
                     "ljspeech_style_melgan.v1" \
) # veja outros em https://github.com/kan-bayashi/ParallelWaveGAN/blob/master/parallel_wavegan/utils/utils.py

export NOISE_LEVEL_LIST=(10 1 0.1 0.01 0.001 0)
export STR_NOISE_LEVEL_LIST=$(echo ${NOISE_LEVEL_LIST[@]})
