BASE_DATASET_URL="http://festvox.org/cmuarctic/packed"

if [ -d "$DATASET_ORIGINAL" ] && [ "$(ls -A $DATASET_ORIGINAL)" ]; then
    echo "Dataset already exists. Skipping download."
    cd $ROOT_DIR
    return 0
fi

mkdir -p $DATASET_ORIGINAL
cd $DATASET_ORIGINAL

for SPEAKER in "${SPEAKERS[@]}"; do
    url="${BASE_DATASET_URL}/cmu_us_${SPEAKER}_arctic.tar.bz2"
    echo "Baixando: $url"
    wget "$url" &
done
wait

for SPEAKER in "${SPEAKERS[@]}"; do
    tar -xvjf cmu_us_${SPEAKER}_arctic.tar.bz2 > /dev/null
    mkdir -p "${SPEAKER}"
    
    FILES=$(find "cmu_us_${SPEAKER}_arctic/wav/" -type f -name "*.wav")
    
    if [[ -n "$FILES_TO_KEEP" ]]; then
        FILES=$(echo "$FILES" | head -n "$FILES_TO_KEEP")
    fi
    
    echo "$FILES" | while read file; do
        cp "$file" "${SPEAKER}/"
    done
    rm -rf "cmu_us_${SPEAKER}_arctic"
done
rm -f ./*

cd $ROOT_DIR