cd $ROOT_DIR

for SPEAKER in "${SPEAKERS[@]}"; do
    mkdir -p ${DATASET_GENERATED}/wav/${SPEAKER}/bonafide
    for file in ${DATASET_ORIGINAL}/${SPEAKER}/*.wav; do
        filename=$(basename "$file")
        output_file=${DATASET_GENERATED}/wav/${SPEAKER}/bonafide/$filename
        ffmpeg -i "$file" -ar 22050 "$output_file"
    done
done