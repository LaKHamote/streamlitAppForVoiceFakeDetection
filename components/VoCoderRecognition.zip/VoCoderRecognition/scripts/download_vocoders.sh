cd $ROOT_DIR

for VOCODER_TAG in "${VOCODER_TAGS[@]}"; do

if [ -d "vocoder-models/$VOCODER_TAG" ] && [ "$(ls -A vocoder-models/$VOCODER_TAG)" ]; then
    echo "Directory for $VOCODER_TAG already exist. Skipping download."
    continue
fi

python3 -c "
import os
from parallel_wavegan.utils import download_pretrained_model
download_pretrained_model('${VOCODER_TAG}', 'vocoder-models')
"
done