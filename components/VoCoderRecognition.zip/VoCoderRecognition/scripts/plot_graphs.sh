cd $DATASET_ORIGINAL

for SPEAKER in "${SPEAKERS[@]}"; do
    python3 ${ROOT_DIR}/duration_dist.py ./${SPEAKER} duration_${SPEAKER}.png "Histogram of ${SPEAKER} audio duration"
done

cd $ROOT_DIR
