cd $ROOT_DIR

generate_synthetic() {
   local SPEAKER=$1
   local VOCODER_TAG=$2
   cd $ROOT_DIR

   parallel-wavegan-preprocess \
       --config vocoder-models/${VOCODER_TAG}/config.yml \
       --rootdir ${DATASET_GENERATED}/wav/${SPEAKER}/bonafide \
       --dumpdir dump

   parallel-wavegan-decode \
       --checkpoint $(ls vocoder-models/${VOCODER_TAG}/checkpoint*.pkl -1) \
       --dumpdir dump \
       --normalize-before \
       --outdir ${DATASET_GENERATED}/wav/${SPEAKER}/${VOCODER_TAG}

   rm -rf dump
}



for SPEAKER in "${SPEAKERS[@]}"; do
  for VOCODER_TAG in "${VOCODER_TAGS[@]}"; do
    generate_synthetic $SPEAKER $VOCODER_TAG
  done
done
