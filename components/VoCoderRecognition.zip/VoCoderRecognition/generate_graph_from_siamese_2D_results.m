% EXECUTE FIRST: train_inference.m or/and valid_inference.m

function plot_train_inference(num_fig, train_inference_history, epoch, vocoder)

        figure(num_fig);
	hold on;

	min_x = min(train_inference_history(:, 4));
	max_x = max(train_inference_history(:, 4));
	min_y = min(train_inference_history(:, 5));
	max_y = max(train_inference_history(:, 5));


	xlim([min_x max_x]);
	ylim([min_y max_y]);


	filtered_train_inference_history = train_inference_history(train_inference_history(:, 1) == epoch, :);

	colors = filtered_train_inference_history(:, 3);  % Valores da terceira coluna para cor
	unique_colors = unique(colors);
	for v = 1:length(unique_colors)
	    voc=unique_colors(v);
	    filtered_train_inference_history_voc = filtered_train_inference_history(filtered_train_inference_history(:,3) == voc , :);
	    x = filtered_train_inference_history_voc(:, 4);
	    y = filtered_train_inference_history_voc(:, 5);
	    

	    scatter(x, y, 5, ones(1,length(x))*voc, 'filled');
	   
	end

	legend(vocoder, 'Location', 'bestoutside');

	% Adicionar títulos e rótulos
	title(['Epoch ' , num2str(epoch)]);
	xlabel('X');
	ylabel('Y');

	hold off; % Liberar o gráfico

end



function save_train_sequence(subdir, train_inference_history, vocoder)

	mkdir(subdir)
	min_epoch = min(train_inference_history(:, 1));
	max_epoch = max(train_inference_history(:, 1));
	num_fig=1000
        for epoch = min_epoch:max_epoch
            plot_train_inference(num_fig, train_inference_history, epoch, vocoder)
            nome_arquivo = strcat(subdir, 'inference_%05d.png');
            nome_arquivo = sprintf(nome_arquivo, epoch)
            print(nome_arquivo, '-dpng');
            close(num_fig)
            num_fig=num_fig+1
        end
        
        printf("Enter in subdirectory and run:\n");
        printf("ffmpeg -framerate 10 -i inference_%%05d.png -c:v libx264 -pix_fmt yuv420p output_video.mp4\n");
end

