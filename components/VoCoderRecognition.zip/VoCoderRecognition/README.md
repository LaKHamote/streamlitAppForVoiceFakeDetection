# Projeto de Detecção de Vocoders 

Este repositório contém scripts e ferramentas para treinar modelos de redes neurais para detecção de vocoders, por meio da abordagem contida no paper link. Abaixo estão as instruções para configurar o ambiente, baixar os recursos necessários e treinar e testar os modelos.

## Requisitos 

Foi usado para este projeto Python na versão 3.8.10.
Certifique-se de que você tenha instalado os pacotes listados no arquivo `requirements.txt`.

```bash
pip3 install -r requirements.txt
```

Instale também o ffmpeg.

```bash
sudo apt install ffmpeg -y
```

### Configuração de ambiente CUDA

Os modelos foram criados e testados com FastAI e PyTorch com suporte para CUDA 12.0. Confira o comando

```bash
nvidia-smi
```

```
+-----------------------------------------------------------------------------+
| NVIDIA-SMI 525.147.05   Driver Version: 525.147.05   CUDA Version: 12.0     |
|-------------------------------+----------------------+----------------------+
| GPU  Name        Persistence-M| Bus-Id        Disp.A | Volatile Uncorr. ECC |
| Fan  Temp  Perf  Pwr:Usage/Cap|         Memory-Usage | GPU-Util  Compute M. |
|                               |                      |               MIG M. |
|===============================+======================+======================|
|   0  Tesla V100S-PCI...  On   | 00000000:17:00.0 Off |                    0 |
| N/A   51C    P0    30W / 250W |      4MiB / 32768MiB |      0%      Default |
|                               |                      |                  N/A |
+-------------------------------+----------------------+----------------------+
|   1  Tesla V100S-PCI...  On   | 00000000:65:00.0 Off |                    0 |
| N/A   52C    P0    31W / 250W |      4MiB / 32768MiB |      0%      Default |
|                               |                      |                  N/A |
+-------------------------------+----------------------+----------------------+
```


## Variáveis de Ambiente e Criação da Pasta de Trabalho

As seguintes variáveis de ambientes serão usadas por todo o processo:


```
export ROOT_DIR=$(cd;pwd)/vocoder-detection
export DATASET_ORIGINAL="dataset/original"
export DATASET_GENERATED="dataset/generated"
export REPORT="report"

export GIT_LOCAL=${ROOT_DIR}/vocoder-detector

export SPEAKERS=("awb" "bdl" "clb" "jmk" "ksp" "rms" "slt" )
export STR_SPEAKERS=${SPEAKERS[@]}


export VOCODER_TAGS=("ljspeech_full_band_melgan.v2" \
                     "ljspeech_hifigan.v1" \
                     "ljspeech_melgan.v3.long" \
                     "ljspeech_multi_band_melgan.v2" \
                     "ljspeech_parallel_wavegan.v3" \
                      "ljspeech_style_melgan.v1")

export NOISE_LEVEL_LIST=(10 1 0.1 0.01 0.001 0)
export STR_NOISE_LEVEL_LIST=$(echo ${NOISE_LEVEL_LIST[@]})


```

O projeto se desenvolverá em ROOT_DIR:

```bash
mkdir $ROOT_DIR
```
Mude o caminho acima conforme necessário.

Baixe o código fonte:

```bash
GITHUB_USER=youruser
GITHUB_TOKEN=yourtoken
GIT_REMOTE=https://${GITHUB_USER}:${GITHUB_TOKEN}@github.com/fbvidal/VoCoderRecognition.git
cd $ROOT_DIR
git clone $GIT_REMOTE $GIT_LOCAL
```


## Baixar Dataset de Voz

O dataset do projeto é o disponibilizado em http://festvox.org/cmu_arctic.

Os locutores usados são: US bdl (US male); US slt (US female); US jmk (Canadian male); US awb (Scottish male); US rms (US male); US clb (US female); US ksp (Indian male).


```bash

BASE_DATASET_URL="http://festvox.org/cmuarctic/packed"
cd $ROOT_DIR
mkdir -p $DATASET_ORIGINAL
cd $DATASET_ORIGINAL

for SPEAKER in "${SPEAKERS[@]}"; do
    url="${BASE_DATASET_URL}/cmu_us_${SPEAKER}_arctic.tar.bz2"
    echo "Baixando: $url"
    wget "$url" &
done
wait

for SPEAKER in "${SPEAKERS[@]}"; do
    tar -xvjf cmu_us_${SPEAKER}_arctic.tar.bz2
    mkdir ${SPEAKER}
    cp cmu_us_${SPEAKER}_arctic/wav/* ${SPEAKER}/
    rm -r cmu_us_${SPEAKER}_arctic
done
rm -f ./*
```

### Plotar a Distribuição da Duração dos Áudios

```bash
cd $ROOT_DIR/$DATASET_ORIGINAL

for SPEAKER in "${SPEAKERS[@]}"; do
    python3 ${GIT_LOCAL}/duration_dist.py ./${SPEAKER} duration_${SPEAKER}.png "Histogram of ${SPEAKER} audio duration"
done

```

![Image 1](resources/duration_jmk.png) 
![Image 2](resources/duration_ksp.png) 
![Image 3](resources/duration_rms.png) 


## Criação dos Áudios Sintéticos

Os áudios são usados para treinamento, validação e testes. Tantos os áudios verdadeiros (bonafide) quanto os sintéticos são usados para tais tarefas.
Para gerar os áudios sintéticos neste trabalho, usamos os vocoders neurais, já treinados, disponibilizados por Tomoki Hayashi [aqui](https://github.com/kan-bayashi/ParallelWaveGAN).
A técnica de gerar audios sintéticos para imitar áudios verdadeiros já existentes, nesse contexto, chama-se self-vocoding.

### Baixar Vocoders

Baixe os vocoders com o seguinte script:

```bash
pip3 install parallel_wavegan

cd $ROOT_DIR

for VOCODER_TAG in "${VOCODER_TAGS[@]}"; do
python3 -c "
import os
from parallel_wavegan.utils import download_pretrained_model
download_pretrained_model('${VOCODER_TAG}', 'vocoder-models')
"
done
```

O script acima fará o download dos vocoders e os armazenará na pasta `./vocoder-models`.

### Reamostragem dos Áudios Originais

Os áudios originais foram amostrados em 16000Hz, no entanto, os vocoders acima usam taxa de amostragem de 22050Hz. Usaremos o ffmpeg para fazer a reamostragem.

```bash

cd $ROOT_DIR

for SPEAKER in "${SPEAKERS[@]}"; do
    mkdir -p ${DATASET_GENERATED}/wav/${SPEAKER}/bonafide
    for file in ${DATASET_ORIGINAL}/${SPEAKER}/*.wav; do
        filename=$(basename "$file")
        output_file=${DATASET_GENERATED}/wav/${SPEAKER}/bonafide/$filename
        ffmpeg -i "$file" -ar 22050 "$output_file"
    done
done
```

### Gerar os áudios sintéticos

Para gerar os áudios sintéticos por meio dos vocoders neurais acima, execute:

```bash

cd $ROOT_DIR

generate_synthetic() {
   local SPEAKER=$1
   local VOCODER_TAG=$2
   cd $ROOT_DIR

   parallel-wavegan-preprocess \
       --config vocoder-models/${VOCODER_TAG}/config.yml \
       --rootdir ${DATASET_GENERATED}/wav/${SPEAKER}/bonafide \
       --dumpdir dump

   parallel-wavegan-decode \
       --checkpoint $(ls vocoder-models/${VOCODER_TAG}/checkpoint*.pkl -1) \
       --dumpdir dump \
       --normalize-before \
       --outdir ${DATASET_GENERATED}/wav/${SPEAKER}/${VOCODER_TAG}

   rm -rf dump
}



for SPEAKER in "${SPEAKERS[@]}"; do
  for VOCODER_TAG in "${VOCODER_TAGS[@]}"; do
    generate_synthetic $SPEAKER $VOCODER_TAG
  done
done

```

## Gerar Espectogramas

Neste projeto foram usados, para treinar as redes neurais, espectogramas dos locutores, com diferentes adições de ruídos.
O código abaixo gera os espectogramas utilizados:

```bash
cd $GIT_LOCAL
python3
```

```python

from simple_detector_creator import generate_specs
from pathlib import Path
import os

str_noise_level_list = os.getenv("STR_NOISE_LEVEL_LIST", "")
noise_level_list = [int(value) if float(value).is_integer() else float(value) for value in str_noise_level_list.split()]

dataset_generated = os.getenv("DATASET_GENERATED")
root_dir=os.getenv("ROOT_DIR")

audio_root_paths = [os.path.join(root_dir, dataset_generated, "wav", d) for d in os.listdir(os.path.join(root_dir, dataset_generated, "wav"))]



for audio_root_path in audio_root_paths:
   audio_root_path = Path(audio_root_path)
   for noise in noise_level_list:
      spec_root_path = os.path.join(audio_root_path, "../../spec", str(noise), audio_root_path.name)
      spec_root_path = Path(spec_root_path)
      if not spec_root_path.exists():
         spec_root_path.mkdir(parents=True)
         generate_specs('mel', spec_root_path, audio_root_path, noise)
      else:
         print(f"A pasta já existe: {spec_root_path}")


```

Abaixo exemplos de alguns espectogramas gerados:

![Image 3](resources/jmk_22050_arctic_a0001.png)
Imagem gerada a partir de um áudio bonafide, com AWGN.

![Image 4](resources/jmk_22050_arctic_a0001_gen.png)
Imagem gerada a partir do vocoder hifigan, sem AWGN.

## Treinar Detector Simples

![Image 1](resources/cnn_spec.png)

### Escolha da rede neural convolucional clássica

Serão testadas as redes alexnet, resnet34, resnet50, vgg16 e vgg19 na totalidade dos ruídos e dos locutores. 

Antes, devemos gerar uma pasta unindo, via link simbólico, todos os specs de todos os ruídos e todos os locutores.

```bash
cd $ROOT_DIR

VOCODER_TAGS_AND_BONAFIDE=("${VOCODER_TAGS[@]}" "bonafide")

for VOCODER_TAG in "${VOCODER_TAGS_AND_BONAFIDE[@]}"; do
    DEST_FOLDER=$ROOT_DIR/${DATASET_GENERATED}/spec/all_noises/all_speakers/${VOCODER_TAG}
    echo D: ${DEST_FOLDER}

    for NOISE_LEVEL in "${NOISE_LEVEL_LIST[@]}"; do
        for SPEAKER in "${SPEAKERS[@]}"; do
            SOURCE_FOLDER=$ROOT_DIR/${DATASET_GENERATED}/spec/${NOISE_LEVEL}/${SPEAKER}/${VOCODER_TAG}
            echo S: ${SOURCE_FOLDER}
            for FILE in ${SOURCE_FOLDER}/*; do
                EXT="${FILE##*.}"
                NEW_FILE=${DEST_FOLDER}/${RANDOM}${RANDOM}${RANDOM}${RANDOM}.${EXT}
                echo ------------------- LINK
                echo F: $FILE
                echo NF: $NEW_FILE
                mkdir -p "$(dirname "$NEW_FILE")"
                ln -s "$FILE" "$NEW_FILE"
            done
        done
    done

done

```

Podemos treinar a rede usando a estrutura de diretorio e links simbólicos criados acima.

```bash
cd $GIT_LOCAL
python3
```

```python
from simple_detector_creator import create_simple_detector
from fastai.vision.all import *
import os

root_dir = os.getenv("ROOT_DIR", "")
dataset_generated = os.getenv("DATASET_GENERATED", "")
report = os.getenv("REPORT", "")

create_simple_detector(
                    spec_root_path= os.path.join(root_dir , dataset_generated , "spec", "all_noises" , "all_speakers"),
                    cnn_arch_list=[alexnet, resnet34, resnet50, vgg16_bn, vgg19_bn],
                    epochs=100,
                    patience=20,
                    report_dir = os.path.join(root_dir, report, "allnoises_allspeakers")
)


```
Os resultados para o treinamento acima foram:

para alexnet:

![alexnet_32_mel_loss.png](resources/alexnet_32_mel_loss.png)
![alexnet_32_mel_roc.png](resources/alexnet_32_mel_roc.png)

para resnet34:

![resnet34_32_mel_loss.png](resources/resnet34_32_mel_loss.png)
![resnet34_32_mel_roc.png](resources/resnet34_32_mel_roc.png)

para resnet50:

![resnet50_32_mel_loss.png](resources/resnet50_32_mel_loss.png)
![resnet50_32_mel_roc.png](resources/resnet50_32_mel_roc.png)

para vgg_16:

![vgg16_bn_32_mel_loss.png](resources/vgg16_bn_32_mel_loss.png)
![vgg16_bn__roc.png](resources/vgg16_bn__roc.png)

para vgg_19:

![vgg19_bn_32_mel_loss.png](resources/vgg19_bn_32_mel_loss.png)
![vgg19_bn_32_mel_roc.png](resources/vgg19_bn_32_mel_roc.png)

É possível verificar que a rede vgg_19 obteve a melhor performance. Será essa rede a escolhida para nossos próximos testes.


## Teste com speaker externo

Faremos agora vários treinamentos usando a rede escolhida (vgg_19). Para cada treinamento, será deixado um speaker de fora, que será considerado speaker externo. Ao final de cada treinamento usaremos o speaker externo para fazer inferências para avaliar como as redes treinadas se generalizam.

Primeiramente, devemos criar uma estrutura de diretórios que será a fonte dos treinamentos para os speakers externos. Para cada speaker, este fará papel de speaker externo uma vez e não poderá, nessa vez, fazer parte do treinamento.

```bash
cd $ROOT_DIR
VOCODER_TAGS_AND_BONAFIDE=("${VOCODER_TAGS[@]}" "bonafide")

for EXTERNAL_SPEAKER in "${SPEAKERS[@]}"; do
    INTERNAL_SPEAKERS=()
    for INTERNAL_SPEAKER in "${SPEAKERS[@]}"; do
        if [[ "$EXTERNAL_SPEAKER" != "$INTERNAL_SPEAKER" ]]; then
            INTERNAL_SPEAKERS+=("$INTERNAL_SPEAKER")
        fi
    done
    echo "Internal speakers: " "${INTERNAL_SPEAKERS[@]}"

    for VOCODER_TAG in "${VOCODER_TAGS_AND_BONAFIDE[@]}"; do
        DEST_FOLDER=$ROOT_DIR/${DATASET_GENERATED}/spec/all_noises/all_speakers_but_${EXTERNAL_SPEAKER}/${VOCODER_TAG}
        echo D: ${DEST_FOLDER}

        for NOISE_LEVEL in "${NOISE_LEVEL_LIST[@]}"; do
            for SPEAKER in "${INTERNAL_SPEAKERS[@]}"; do
                SOURCE_FOLDER=$ROOT_DIR/${DATASET_GENERATED}/spec/${NOISE_LEVEL}/${SPEAKER}/${VOCODER_TAG}
                echo S: ${SOURCE_FOLDER}
                for FILE in ${SOURCE_FOLDER}/*; do
                    EXT="${FILE##*.}"
                    NEW_FILE=${DEST_FOLDER}/${RANDOM}${RANDOM}${RANDOM}${RANDOM}.${EXT}
                    echo ------------------- LINK
                    echo F: $FILE
                    echo NF: $NEW_FILE
                    mkdir -p "$(dirname "$NEW_FILE")"
                    ln -s "$FILE" "$NEW_FILE"
               done
            done
        done

    done
done

    
````

Agora, podemos treinar as redes, serão vários treinamentos, um para cada speaker externo, que ficará de fora do treinamento.

```bash
cd $GIT_LOCAL
python3
```

```python
from simple_detector_creator import create_simple_detector
from fastai.vision.all import *
import os

root_dir = os.getenv("ROOT_DIR", "")
dataset_generated = os.getenv("DATASET_GENERATED", "")
report = os.getenv("REPORT", "")
str_speakers = os.getenv("STR_SPEAKERS")
speakers = str_speakers.split()

for external_speaker in speakers:
    create_simple_detector(
                    spec_root_path= os.path.join(root_dir , dataset_generated , "spec", "all_noises" , "all_speakers_but_" + external_speaker ),
                    cnn_arch_list=[vgg19_bn],
                    epochs=100,
                    patience=20,
                    report_dir = os.path.join(root_dir, report, "allnoises_allspeakers_but_" + external_speaker)
    )


```

Seguem os resultados dos treinamentos acima:

para all speakers but awb: 

![vgg19_bn_32_mel_loss.png](resources/vgg19_bn_32_mel_loss_allbutawb.png)
![vgg19_bn_32_mel_roc.png](resources/vgg19_bn_32_mel_roc_allbutawb.png)

para all speakers but bdl:

![vgg19_bn_32_mel_loss.png](resources/vgg19_bn_32_mel_loss_allbutbdl.png)
![vgg19_bn_32_mel_roc.png](resources/vgg19_bn_32_mel_roc_allbutbdl.png)

para all speakers but clb:

![vgg19_bn_32_mel_loss.png](resources/vgg19_bn_32_mel_loss_allbutclb.png)
![vgg19_bn_32_mel_roc.png](resources/vgg19_bn_32_mel_roc_allbutclb.png)

para all speakers but jmk:

![vgg19_bn_32_mel_loss.png](resources/vgg19_bn_32_mel_loss_allbutjmk.png)
![vgg19_bn_32_mel_roc.png](resources/vgg19_bn_32_mel_roc_allbutjmk.png)

para all speakers but ksp:

![vgg19_bn_32_mel_loss.png](resources/vgg19_bn_32_mel_loss_allbutksp.png)
![vgg19_bn_32_mel_roc.png](resources/vgg19_bn_32_mel_roc_allbutksp.png)

para all speakers but rms:

![vgg19_bn_32_mel_loss.png](resources/vgg19_bn_32_mel_loss_allbutrms.png)
![vgg19_bn_32_mel_roc.png](resources/vgg19_bn_32_mel_roc_allbutrms.png)

para all speakers but slt:

![vgg19_bn_32_mel_loss.png](resources/vgg19_bn_32_mel_loss_allbutslt.png)
![vgg19_bn_32_mel_roc.png](resources/vgg19_bn_32_mel_roc_allbutslt.png)

Agora que as redes foram treinadas, vamos usar cada speaker como speaker externo e inferir, para cada nível de ruído separadamente, a classe de cada amostra (i.e. qual vocoder gerou cada amostra).

```bash
cd $GIT_LOCAL
python3
```

```python

from simple_detector_tester import test_simple_detector
from fastai.vision.all import *
import os

root_dir = os.getenv("ROOT_DIR", "")
dataset_generated = os.getenv("DATASET_GENERATED", "")
report = os.getenv("REPORT", "")
str_speakers = os.getenv("STR_SPEAKERS")
speakers = str_speakers.split()
str_noise_level_list = os.getenv("STR_NOISE_LEVEL_LIST", "")
noise_level_list = [int(value) if float(value).is_integer() else float(value) for value in str_noise_level_list.split()]

best_arch = vgg19_bn
str_best_arch = best_arch.__name__

for speaker in speakers:
    for noise_level in noise_level_list:
        print("speaker: " + speaker + " noise: " + str(noise_level ))
        detector_model_file = os.path.join(root_dir, dataset_generated, "spec", "all_noises", "all_speakers_but_" + speaker,  str_best_arch + "_32")
        inference_mel_root_path = os.path.join(root_dir, dataset_generated, "spec", str(noise_level), speaker)
        report_dir = os.path.join(root_dir, report, "external", speaker, str(noise_level))
        title_basename = speaker + "_" + str(noise_level)
        test_simple_detector(
                        detector_model_file=detector_model_file,
                        inference_mel_root_path=inference_mel_root_path,
                        cnn_arch=best_arch,
                        report_dir=report_dir,
                        title_basename=title_basename)


```

O resultado da inferência segue assim:

-para **awb** como speaker externo:

noise level = 0 (SNR = +inf dB):  
<img src="resources/roc_awb_0.png" width="500" height="500"> <img src="resources/confusion_matrix_awb_0.png" width="500" height="500">

noise level = 0.001 (SNR = 30dB):  
<img src="resources/roc_awb_0.001.png" width="500" height="500"> <img src="resources/confusion_matrix_awb_0.001.png" width="500" height="500">

noise level = 0.01 (SNR = 20dB):  
<img src="resources/roc_awb_0.01.png" width="500" height="500"> <img src="resources/confusion_matrix_awb_0.01.png" width="500" height="500">

noise level = 0.1 (SNR = 10dB):  
<img src="resources/roc_awb_0.1.png" width="500" height="500"> <img src="resources/confusion_matrix_awb_0.1.png" width="500" height="500">

noise level = 1 (SNR = 0dB):  
<img src="resources/roc_awb_1.png" width="500" height="500"> <img src="resources/confusion_matrix_awb_1.png" width="500" height="500">

noise level = 10 (SNR = -10dB):  
<img src="resources/roc_awb_10.png" width="500" height="500"> <img src="resources/confusion_matrix_awb_10.png" width="500" height="500">

---

-para **bdl** como speaker externo:

noise level = 0 (SNR = +inf dB):  
<img src="resources/roc_bdl_0.png" width="500" height="500"> <img src="resources/confusion_matrix_bdl_0.png" width="500" height="500">

noise level = 0.001 (SNR = 30dB):  
<img src="resources/roc_bdl_0.001.png" width="500" height="500"> <img src="resources/confusion_matrix_bdl_0.001.png" width="500" height="500">

noise level = 0.01 (SNR = 20dB):  
<img src="resources/roc_bdl_0.01.png" width="500" height="500"> <img src="resources/confusion_matrix_bdl_0.01.png" width="500" height="500">

noise level = 0.1 (SNR = 10dB):  
<img src="resources/roc_bdl_0.1.png" width="500" height="500"> <img src="resources/confusion_matrix_bdl_0.1.png" width="500" height="500">

noise level = 1 (SNR = 0dB):  
<img src="resources/roc_bdl_1.png" width="500" height="500"> <img src="resources/confusion_matrix_bdl_1.png" width="500" height="500">

noise level = 10 (SNR = -10dB):  
<img src="resources/roc_bdl_10.png" width="500" height="500"> <img src="resources/confusion_matrix_bdl_10.png" width="500" height="500">

---

-para **clb** como speaker externo:

noise level = 0 (SNR = +inf dB):  
<img src="resources/roc_clb_0.png" width="500" height="500"> <img src="resources/confusion_matrix_clb_0.png" width="500" height="500">

noise level = 0.001 (SNR = 30dB):  
<img src="resources/roc_clb_0.001.png" width="500" height="500"> <img src="resources/confusion_matrix_clb_0.001.png" width="500" height="500">

noise level = 0.01 (SNR = 20dB):  
<img src="resources/roc_clb_0.01.png" width="500" height="500"> <img src="resources/confusion_matrix_clb_0.01.png" width="500" height="500">

noise level = 0.1 (SNR = 10dB):  
<img src="resources/roc_clb_0.1.png" width="500" height="500"> <img src="resources/confusion_matrix_clb_0.1.png" width="500" height="500">

noise level = 1 (SNR = 0dB):  
<img src="resources/roc_clb_1.png" width="500" height="500"> <img src="resources/confusion_matrix_clb_1.png" width="500" height="500">

noise level = 10 (SNR = -10dB):  
<img src="resources/roc_clb_10.png" width="500" height="500"> <img src="resources/confusion_matrix_clb_10.png" width="500" height="500">

---

-para **jmk** como speaker externo:

noise level = 0 (SNR = +inf dB):  
<img src="resources/roc_jmk_0.png" width="500" height="500"> <img src="resources/confusion_matrix_jmk_0.png" width="500" height="500">

noise level = 0.001 (SNR = 30dB):  
<img src="resources/roc_jmk_0.001.png" width="500" height="500"> <img src="resources/confusion_matrix_jmk_0.001.png" width="500" height="500">

noise level = 0.01 (SNR = 20dB):  
<img src="resources/roc_jmk_0.01.png" width="500" height="500"> <img src="resources/confusion_matrix_jmk_0.01.png" width="500" height="500">

noise level = 0.1 (SNR = 10dB):  
<img src="resources/roc_jmk_0.1.png" width="500" height="500"> <img src="resources/confusion_matrix_jmk_0.1.png" width="500" height="500">

noise level = 1 (SNR = 0dB):  
<img src="resources/roc_jmk_1.png" width="500" height="500"> <img src="resources/confusion_matrix_jmk_1.png" width="500" height="500">

noise level = 10 (SNR = -10dB):  
<img src="resources/roc_jmk_10.png" width="500" height="500"> <img src="resources/confusion_matrix_jmk_10.png" width="500" height="500">

---

-para **ksp** como speaker externo:

noise level = 0 (SNR = +inf dB):  
<img src="resources/roc_ksp_0.png" width="500" height="500"> <img src="resources/confusion_matrix_ksp_0.png" width="500" height="500">

noise level = 0.001 (SNR = 30dB):  
<img src="resources/roc_ksp_0.001.png" width="500" height="500"> <img src="resources/confusion_matrix_ksp_0.001.png" width="500" height="500">

noise level = 0.01 (SNR = 20dB):  
<img src="resources/roc_ksp_0.01.png" width="500" height="500"> <img src="resources/confusion_matrix_ksp_0.01.png" width="500" height="500">

noise level = 0.1 (SNR = 10dB):  
<img src="resources/roc_ksp_0.1.png" width="500" height="500"> <img src="resources/confusion_matrix_ksp_0.1.png" width="500" height="500">

noise level = 1 (SNR = 0dB):  
<img src="resources/roc_ksp_1.png" width="500" height="500"> <img src="resources/confusion_matrix_ksp_1.png" width="500" height="500">

noise level = 10 (SNR = -10dB):  
<img src="resources/roc_ksp_10.png" width="500" height="500"> <img src="resources/confusion_matrix_ksp_10.png" width="500" height="500">

---

-para **rms** como speaker externo:

noise level = 0 (SNR = +inf dB):  
<img src="resources/roc_rms_0.png" width="500" height="500"> <img src="resources/confusion_matrix_rms_0.png" width="500" height="500">

noise level = 0.001 (SNR = 30dB):  
<img src="resources/roc_rms_0.001.png" width="500" height="500"> <img src="resources/confusion_matrix_rms_0.001.png" width="500" height="500">

noise level = 0.01 (SNR = 20dB):  
<img src="resources/roc_rms_0.01.png" width="500" height="500"> <img src="resources/confusion_matrix_rms_0.01.png" width="500" height="500">

noise level = 0.1 (SNR = 10dB):  
<img src="resources/roc_rms_0.1.png" width="500" height="500"> <img src="resources/confusion_matrix_rms_0.1.png" width="500" height="500">

noise level = 1 (SNR = 0dB):  
<img src="resources/roc_rms_1.png" width="500" height="500"> <img src="resources/confusion_matrix_rms_1.png" width="500" height="500">

noise level = 10 (SNR = -10dB):  
<img src="resources/roc_rms_10.png" width="500" height="500"> <img src="resources/confusion_matrix_rms_10.png" width="500" height="500">

---

-para **slt** como speaker externo:

noise level = 0 (SNR = +inf dB):  
<img src="resources/roc_slt_0.png" width="500" height="500"> <img src="resources/confusion_matrix_slt_0.png" width="500" height="500">

noise level = 0.001 (SNR = 30dB):  
<img src="resources/roc_slt_0.001.png" width="500" height="500"> <img src="resources/confusion_matrix_slt_0.001.png" width="500" height="500">

noise level = 0.01 (SNR = 20dB):  
<img src="resources/roc_slt_0.01.png" width="500" height="500"> <img src="resources/confusion_matrix_slt_0.01.png" width="500" height="500">

noise level = 0.1 (SNR = 10dB):  
<img src="resources/roc_slt_0.1.png" width="500" height="500"> <img src="resources/confusion_matrix_slt_0.1.png" width="500" height="500">

noise level = 1 (SNR = 0dB):  
<img src="resources/roc_slt_1.png" width="500" height="500"> <img src="resources/confusion_matrix_slt_1.png" width="500" height="500">

noise level = 10 (SNR = -10dB):  
<img src="resources/roc_slt_10.png" width="500" height="500"> <img src="resources/confusion_matrix_slt_10.png" width="500" height="500">

---

Os dados de aEER, mostrados acima, tabulados, ficam: 

|SNR (dB)|awb|bld|clb|jmk|ksp|rms|slt|
|-|-|-|-|-|-|-|-|
|+inf|0,000416|0,0009070|0,0004047|0,0000000|0,0004093|0,0000000|0,0033022|
|30|0,0012875|0,0022337|0,0016484|0,0000000|0,0004202|0,0000000|0,0056626|
|20|0,0042519|0,0034351|0,0038019|0,0004105|0,0008501|0,0008299|0,0200379|
|10|0,0118165|0,0171084|0,0182477|0,0026044|0,0029404|0,0025633|0,0731237|
|0|0,0328387|0,0644317|0,0896355|0,0172931|0,0151782|0,0108381|0,1689699|
|-10|0,1458875|0,2058772|0,2893341|0,0762229|0,0996208|0,0746709|0,2940137|  


ou, em forma gráfica:

<img src="resources/aEER.png"  >  

Todos são locutores de língua inglesa, sendo que:  
awb é um homem escocês;  
bdl é um homem americano;  
clb é uma mulher americana;  
jmk é um homem canadense;  
ksp é um homem indiano;  
slt é uma mulher americana;  
rms é um homem americano;  

### Adendo - outros mapeamentos Mel

Todos os procedimentos acima foram realizados para outros mapeamentos Mel: linearmel e antimel. 
O antimel usa mapeamento invertido, de forma que ao contrário da escala Mel, são as frequências mais baixas que são comprimidas, favorecendo as mais altas. Já no mapeamento linearmel, 
se considera a relação "frequencia"="escala mel", ou seja, ao contrário dos mapeamentos anteriores, o linear mel não favorece faixas de frequências em detrimento de outras. Ao linearmel e ao antimel, por coerência comparativa, se aplicam os mesmos bancos de filtros triangulares que já existem na escala Mel.

Temos o seguinte resultado final quando o mapeamento aplicado é o linearmel:

|SNR (dB)|awb|bld|clb|jmk|ksp|rms|slt|
|-|-|-|-|-|-|-|-|
|+INF |0,0008470|0,0004653|0,0000000|0,0000000|0,0000000|0,0000000|0,0004290
|30|0,0055450|0,0013255|0,0008524|0,0012997|0,0004129|0,0000000|0,0092731
|20|0,0122700|0,0065964|0,0042424|0,0048123|0,0008366|0,0016999|0,0246670
|10|0,0290500|0,0316320|0,0316891|0,0204450|0,0042473|0,0113763|0,0741770
|0|0,0736800|0,1222680|0,1405680|0,0792584|0,0309053|0,0473779|0,1773191
|-10|0,2194000|0,2674970|0,3361240|0,2100302|0,1783300|0,1681650|0,3113883

E o seguinte resultado final quando o mapeamento aplicado é o antimel:

|SNR (dB)|awb|bld|clb|jmk|ksp|rms|slt|
|-|-|-|-|-|-|-|-|
|	+INF	|	0,00343	|	0,0048249117	|	0	|	0,001330967	|	0,0012869414	|	0	|	0,0004226542
|	30	|	0,0221139	|	0,004507064	|	0,0020443702	|	0,001290979	|	0,0012696381	|	0,002623249	|	0,0080864558
|	20	|	0,105467	|	0,01810027	|	0,01386173	|	0,01200416	|	0,01184219832	|	0,006319099	|	0,03355567
|	10	|	0,2504572	|	0,09658183	|	0,0553284488	|	0,07363374	|	0,06594937	|	0,06005597768	|	0,1163306
|	0	|	0,36118369	|	0,261534539	|	0,20705508	|	0,225633819	|	0,2179241765	|	0,1912021	|	0,28840492
|	-10	|	0,4547184	|	0,4436347	|	0,452903999	|	0,4242254	|	0,4508762	|	0,4029134	|	0,466230927



## Comparação Mel x Linearmel x Antimel

A seguinte tabela compara a performance dos sistemas quando treinados com espectogramas mel, linearmel, antimel:

|SNR (dB)|awb|bld|clb|jmk|ksp|rms|slt|
|-|-|-|-|-|-|-|-|
|	+INF	|	mel	|	isomel	|	isomel/antimel	|	mel/isomel	|	isomel	|	mel/isomel/antimel	|	antimel
|	30	|	mel	|	isomel	|	isomel	|	mel	|	isomel	|	mel/isomel	|	mel
|	20	|	mel	|	mel	|	mel	|	mel	|	isomel	|	mel	|	mel
|	10	|	mel	|	mel	|	mel	|	mel	|	mel	|	mel	|	mel
|	0	|	mel	|	mel	|	mel	|	mel	|	mel	|	mel	|	mel
|	-10	|	mel	|	mel	|	mel	|	mel	|	mel	|	mel	|	mel

Se conclui que a aplicação dos mapeamentos isomel ou antimel supera a do mapeamento mel em cenários sem ruídos, uma vez que o ruído mascara as ocorrências de artefatos gerados pelos sintetizadores nas altas frequencias, regiões estas de potência sonora menor.
