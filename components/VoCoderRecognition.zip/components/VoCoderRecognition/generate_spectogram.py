from lib.melspectrogram_custom import generate_specs
from pathlib import Path
import os

str_noise_level_list = os.getenv("STR_NOISE_LEVEL_LIST", "")
noise_level_list = [int(value) if float(value).is_integer() else float(value) for value in str_noise_level_list.split()]

dataset_generated = os.getenv("DATASET_GENERATED")
root_dir=os.getenv("ROOT_DIR")

audio_root_paths = [os.path.join(root_dir, dataset_generated, "wav", d) for d in os.listdir(os.path.join(root_dir, dataset_generated, "wav"))]

for audio_root_path in audio_root_paths:
   audio_root_path = Path(audio_root_path)
   for noise in noise_level_list:
      spec_root_path = os.path.join(audio_root_path, "../../spec", str(noise), audio_root_path.name)
      spec_root_path = Path(spec_root_path)

      if not spec_root_path.exists():
         spec_root_path.mkdir(parents=True)
         generate_specs('mel', spec_root_path, audio_root_path, noise)
      else:
         print(f"A pasta já existe: {spec_root_path}")