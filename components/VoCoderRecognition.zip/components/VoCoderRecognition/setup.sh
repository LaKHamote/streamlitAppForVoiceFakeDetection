export BASH_SOURCE_DIR=$(pwd)
export VOCODERREC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "⚙️ Setting environment variables..."
source $VOCODERREC_DIR/scripts/env.sh

echo "⬇️ Downloading voice dataset..."
source $VOCODERREC_DIR/scripts/download_dataset.sh

echo "📊 Plotting audio duration distribution..."
source $VOCODERREC_DIR/scripts/plot_graphs.sh

echo "⬇️ Downloading vocoders..."
source $VOCODERREC_DIR/scripts/download_vocoders.sh

echo "🔄 Resampling original audio files..."
source $VOCODERREC_DIR/scripts/remostragem.sh

echo "🎙️ Generating synthetic audio files..."
source $VOCODERREC_DIR/scripts/generate_audios.sh

echo "🎧 Generating spectrograms..."
python3 $VOCODERREC_DIR/generate_spectogram.py 

cd $BASH_SOURCE_DIR